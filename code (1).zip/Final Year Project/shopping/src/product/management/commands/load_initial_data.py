from django.core.management.base import BaseCommand
from product.models import Product, Size, Leather, Color, Category, Blog
from decimal import Decimal
from datetime import datetime

class Command(BaseCommand):
    help = 'Load initial data for products, sizes, leathers, colors, and blogs'

    def handle(self, *args, **kwargs):
        # Create sizes
        sizes = [
            'Small',
            'Medium',
            'Large',
            'Extra Large'
        ]
        
        for name in sizes:
            Size.objects.get_or_create(
                name=name,
            )
            self.stdout.write(f'Created size: {name}')

        # Create leather types
        leathers = [
            'Full-Grain Leather',
            'Top-Grain Leather',
            'Genuine Leather',
            'Exotic Leather'
        ]
        
        for name in leathers:
            Leather.objects.get_or_create(
                name=name,
            )
            self.stdout.write(f'Created leather type: {name}')

        # Create colors
        colors = [
            'Black',
            'Brown',
            'Dark Brown',
            'Light Brown'
        ]
        
        for name in colors:
            Color.objects.get_or_create(
                name=name,
            )
            self.stdout.write(f'Created color: {name}')

        # Create categories
        categories = [
            {
                'name': 'Belts',
                'image': 'categories/blt-1.jpg'
            },
            {
                'name': 'Bags',
                'image': 'categories/bgs-1.jpg'
            },
            {
                'name': 'Jackets',
                'image': 'categories/jckt-1.jpg'
            },
            {
                'name': 'Keychains',
                'image': 'categories/keychains-1.jpg'
            },
            {
                'name': 'Wallets',
                'image': 'categories/neww-1.jpg'
            },
            {
                'name': 'Card Holders',
                'image': 'categories/c1-1.jpg'
            },
            {
                'name': 'Glasses',
                'image': 'categories/glss-1.jpg'
            },
            {
                'name': 'Backpacks',
                'image': 'categories/bgtt-1.jpg'
            }
        ]

        for category_data in categories:
            category, created = Category.objects.get_or_create(
                name=category_data['name'],
                defaults={
                    'image': category_data['image']
                }
            )
            if created:
                self.stdout.write(f'Created category: {category.name}')
            else:
                self.stdout.write(f'Category already exists: {category.name}')

        # Create products
        base_products = [
            {'name': 'Dictum', 'price': '$189.00', 'size': 'Large', 'leather': 'Full-Grain Leather', 'color': 'Black', 'category': 'Wallets', 'for_gender': 'female', 'image': 'products/p19-1.jpg'},
            {'name': 'Integer', 'price': '$124.00', 'size': 'Medium', 'leather': 'Genuine Leather', 'color': 'Brown', 'category': 'Belts', 'for_gender': 'male', 'image': 'products/p21-1.jpg'},
            {'name': 'Lobortis', 'price': '$120.00', 'size': 'Small', 'leather': 'Top-Grain Leather', 'color': 'Dark Brown', 'category': 'Bags', 'for_gender': 'female', 'image': 'products/p20-1.jpg'},
            {'name': 'Pharetra', 'price': '$229.00', 'size': 'Large', 'leather': 'Exotic Leather', 'color': 'Light Brown', 'category': 'Jackets', 'for_gender': 'male', 'image': 'products/p8-1.jpg'},
            {'name': 'Quisque', 'price': '$159.00', 'size': 'Medium', 'leather': 'Full-Grain Leather', 'color': 'Black', 'category': 'Keychains', 'for_gender': 'male', 'image': 'products/p10-1.jpg'},
            {'name': 'Senectus', 'price': '$120.00', 'size': 'Extra Large', 'leather': 'Genuine Leather', 'color': 'Brown', 'category': 'Card Holders', 'for_gender': 'male', 'image': 'products/p11-1.jpg'},
            {'name': 'Vivamus', 'price': '$137.00', 'size': 'Small', 'leather': 'Top-Grain Leather', 'color': 'Dark Brown', 'category': 'Glasses', 'for_gender': 'male', 'image': 'products/p19-1.jpg'},
            {'name': 'Sodales', 'price': '$170.00', 'size': 'Medium', 'leather': 'Full-Grain Leather', 'color': 'Black', 'category': 'Backpacks', 'for_gender': 'male', 'image': 'products/p21-1.jpg'},
            {'name': 'Viverra', 'price': '$139.00', 'size': 'Large', 'leather': 'Exotic Leather', 'color': 'Light Brown', 'category': 'Wallets', 'for_gender': 'male', 'image': 'products/p20-1.jpg'},
            {'name': 'Arcu', 'price': '$149.00', 'size': 'Medium', 'leather': 'Top-Grain Leather', 'color': 'Black', 'category': 'Belts', 'for_gender': 'male', 'image': 'products/p8-1.jpg'},
            {'name': 'Curabitur', 'price': '$199.00', 'size': 'Large', 'leather': 'Full-Grain Leather', 'color': 'Brown', 'category': 'Bags', 'for_gender': 'male', 'image': 'products/p10-1.jpg'},
            {'name': 'Ultrices', 'price': '$210.00', 'size': 'Small', 'leather': 'Genuine Leather', 'color': 'Dark Brown', 'category': 'Jackets', 'for_gender': 'female', 'image': 'products/p11-1.jpg'},
            {'name': 'Tempus', 'price': '$185.00', 'size': 'Medium', 'leather': 'Exotic Leather', 'color': 'Black', 'category': 'Keychains', 'for_gender': 'male', 'image': 'products/p19-1.jpg'},
            {'name': 'Nullam', 'price': '$165.00', 'size': 'Large', 'leather': 'Full-Grain Leather', 'color': 'Brown', 'category': 'Card Holders', 'for_gender': 'male', 'image': 'products/p21-1.jpg'},
            {'name': 'Mauris', 'price': '$142.00', 'size': 'Small', 'leather': 'Top-Grain Leather', 'color': 'Light Brown', 'category': 'Glasses', 'for_gender': 'male', 'image': 'products/p20-1.jpg'},
            {'name': 'Egestas', 'price': '$155.00', 'size': 'Medium', 'leather': 'Full-Grain Leather', 'color': 'Black', 'category': 'Backpacks', 'for_gender': 'male', 'image': 'products/p8-1.jpg'},
            {'name': 'Pulvinar', 'price': '$134.00', 'size': 'Extra Large', 'leather': 'Genuine Leather', 'color': 'Dark Brown', 'category': 'Wallets', 'for_gender': 'male', 'image': 'products/p10-1.jpg'},
        ]

        for product_data in base_products:
            # Convert price from string to Decimal
            price = Decimal(product_data['price'].replace('$', '').replace(',', ''))
            
            # Get related objects
            size = Size.objects.get(name=product_data['size'])
            leather = Leather.objects.get(name=product_data['leather'])
            color = Color.objects.get(name=product_data['color'])
            category = Category.objects.get(name=product_data['category'])

            # Create product
            product, created = Product.objects.get_or_create(
                name=product_data['name'],
                defaults={
                    'price': price,
                    'size': size,
                    'leather': leather,
                    'color': color,
                    'category': category,
                    'description': f'High-quality {product_data["leather"].lower()} product in {product_data["color"].lower()} color',
                    'stock': 10,  # Default stock
                    'for_gender': product_data["for_gender"],
                    'image': product_data["image"]
                }
            )
            
            if created:
                self.stdout.write(f'Created product: {product.name}')
            else:
                self.stdout.write(f'Product already exists: {product.name}')

        # Create blogs
        blogs = [
            {
                'title': 'The Journey to Sustainable Leather: What You Should Know',
                'subtitle': 'Sustainability and Ethics',
                'content': 'Discover how sustainable leather is reshaping the fashion industry—from eco-friendly hide sourcing and vegetable tanning methods to global certifications that ensure ethical practices. Learn the key steps you can look for when choosing leather goods that protect both people and the planet.',
                'image': 'blogs/blg2-1.jpg',
                'author': 'wpthemes',
                'created_at': datetime(2025, 3, 30),
                'comment_count': 0
            },
            {
                'title': 'The Art of Leather Crafting: From Raw Hide to Masterpiece',
                'subtitle': 'Craftsmanship and Heritage',
                'content': 'Delve into the centuries-old techniques of leatherworking, where skilled artisans transform raw hides into stunning creations. We explore traditional tools, hands-on processes, and the heritage behind every stitch that makes each piece truly one-of-a-kind.',
                'image': 'blogs/blg3-1-768x477.jpg',
                'author': 'wpthemes',
                'created_at': datetime(2025, 3, 30),
                'comment_count': 0
            },
            {
                'title': 'Timeless Leather Accessories to Elevate Your Style',
                'subtitle': 'Fashion and Style',
                'content': 'Upgrade your wardrobe with classic leather essentials—belts, bags, wallets, and more—that seamlessly blend with any outfit. We\'ll show you how to pair these versatile pieces for work, weekend, and evening looks, so you always step out in confidence.',
                'image': 'blogs/blg4-1-768x477.jpg',
                'author': 'wpthemes',
                'created_at': datetime(2025, 3, 30),
                'comment_count': 0
            },
            {
                'title': 'How to Care for Your Leather Products: A Complete Guide',
                'subtitle': 'Leather Care and Maintenance',
                'content': 'Keep your leather looking its best with our step-by-step care routine. From gentle cleaning and conditioning to proper storage and waterproofing tips, learn how to protect your investment and extend the life of every piece in your collection.',
                'image': 'blogs/blg-1-768x477.jpg',
                'author': 'wpthemes',
                'created_at': datetime(2025, 3, 28),
                'comment_count': 0
            }
        ]

        for blog_data in blogs:
            blog, created = Blog.objects.get_or_create(
                title=blog_data['title'],
                defaults={
                    'subtitle': blog_data['subtitle'],
                    'content': blog_data['content'],
                    'image': blog_data['image'],
                    'author': blog_data['author'],
                    'created_at': blog_data['created_at'],
                    'comment_count': blog_data['comment_count']
                }
            )
            if created:
                self.stdout.write(f'Created blog: {blog.title}')
            else:
                self.stdout.write(f'Blog already exists: {blog.title}')

        self.stdout.write(self.style.SUCCESS('Successfully loaded initial data')) 