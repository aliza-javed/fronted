from django.urls import path
from . import views

urlpatterns = [
    path('', views.HomePageView.as_view(), name='home'),
    path('products/', views.ProductList.as_view(), name='product-list'),
    path('products/new-arrivals/', views.NewArrivals.as_view(), name='new-arrivals'),
    path('products/<int:pk>/', views.ProductDetail.as_view(), name='product-detail'),
    path('categories/', views.CategoryList.as_view(), name='category-list'),
    path('sizes/', views.SizeList.as_view(), name='size-list'),
    path('colors/', views.ColorList.as_view(), name='color-list'),
    path('leather-types/', views.LeatherList.as_view(), name='leather-list'),
    path('orders/', views.OrderList.as_view(), name='order-list'),
    path('orders/<int:pk>/', views.OrderDetail.as_view(), name='order-detail'),
    path('orders/<int:pk>/status/', views.OrderStatusUpdate.as_view(), name='order-status-update'),
    
    # Blog endpoints
    path('blogs/', views.BlogList.as_view(), name='blog-list'),
    path('blogs/<int:pk>/', views.BlogDetail.as_view(), name='blog-detail'),
    
    # Cart endpoints
    path('cart/', views.CartView.as_view(), name='cart'),
    path('cart/items/<int:item_id>/', views.CartItemView.as_view(), name='cart-item'),
    path('cart/items/<int:item_id>/<str:action>/', views.CartItemQuantityView.as_view(), name='cart-item-quantity'),
    path('modifiers/', views.ModifiersView.as_view(), name='modifiers'),
    path('recommendations/', views.ProductRecommendationView.as_view(), name='product-recommendations'),
]
