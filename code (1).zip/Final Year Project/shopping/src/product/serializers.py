# File: shopping/product/serializers.py

from rest_framework import serializers
from .models import (
    Product, Category, Order, OrderItem, 
    Size, Color, Leather, Cart, CartItem, Blog, ProductRecommendation
)

class SizeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Size
        fields = ['id', 'name']

class ColorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Color
        fields = ['id', 'name']

class LeatherSerializer(serializers.ModelSerializer):
    class Meta:
        model = Leather
        fields = ['id', 'name']

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name', 'image']

class ProductSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)
    size = SizeSerializer(read_only=True)
    color = ColorSerializer(read_only=True)
    leather = LeatherSerializer(read_only=True)
    price = serializers.SerializerMethodField()
    recommended_products = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = ['id', 'name', 'description', 'price', 'image', 'category', 
                 'stock', 'size', 'color', 'leather', 'created_at', 'recommended_products']

    def get_price(self, obj):
        return f'${obj.price:.2f}'

    def get_recommended_products(self, obj):
        recommended = obj.recommended_products.all()[:5]  # Limit to 5 recommendations
        return ProductSerializer(recommended, many=True).data

class OrderItemSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    price_at_time = serializers.SerializerMethodField()
    total_price = serializers.SerializerMethodField()

    class Meta:
        model = OrderItem
        fields = ['id', 'product', 'quantity', 'price_at_time', 'total_price']

    def get_price_at_time(self, obj):
        return f'${obj.price_at_time:.2f}'

    def get_total_price(self, obj):
        return f'${obj.total_price:.2f}'

class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    total_price = serializers.SerializerMethodField()
    shipping_cost = serializers.SerializerMethodField()
    tax = serializers.SerializerMethodField()
    discount = serializers.SerializerMethodField()
    final_price = serializers.SerializerMethodField()
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    payment_status_display = serializers.CharField(source='get_payment_status_display', read_only=True)
    payment_method_display = serializers.CharField(source='get_payment_method_display', read_only=True)

    class Meta:
        model = Order
        fields = [
            'id', 'order_number', 'created_at', 'updated_at',
            'customer_name', 'customer_email', 'customer_phone',
            'shipping_address', 'shipping_city', 'shipping_state',
            'shipping_country', 'shipping_zip_code',
            'status', 'status_display', 'payment_status', 'payment_status_display',
            'payment_method', 'payment_method_display',
            'total_price', 'shipping_cost', 'tax', 'discount', 'final_price',
            'notes', 'tracking_number', 'estimated_delivery',
            'items'
        ]
        read_only_fields = ['order_number', 'created_at', 'updated_at']

    def get_total_price(self, obj):
        return f'${obj.total_price:.2f}'

    def get_shipping_cost(self, obj):
        return f'${obj.shipping_cost:.2f}'

    def get_tax(self, obj):
        return f'${obj.tax:.2f}'

    def get_discount(self, obj):
        return f'${obj.discount:.2f}'

    def get_final_price(self, obj):
        return f'${obj.final_price:.2f}'

class CreateOrderSerializer(serializers.Serializer):
    customer_name = serializers.CharField(max_length=100)
    customer_email = serializers.EmailField()
    customer_phone = serializers.CharField(max_length=20)
    shipping_address = serializers.CharField()
    shipping_city = serializers.CharField(max_length=100)
    shipping_state = serializers.CharField(max_length=100)
    shipping_country = serializers.CharField(max_length=100)
    shipping_zip_code = serializers.CharField(max_length=20)
    payment_method = serializers.ChoiceField(choices=Order.PAYMENT_METHOD_CHOICES)
    notes = serializers.CharField(required=False, allow_blank=True)

class CartItemSerializer(serializers.ModelSerializer):
    product_id = serializers.IntegerField(source='product.id')
    name = serializers.CharField(source='product.name')
    image = serializers.ImageField(source='product.image')
    price = serializers.DecimalField(source='product.price', max_digits=10, decimal_places=2)
    quantity = serializers.IntegerField()
    total_price = serializers.SerializerMethodField()

    class Meta:
        model = CartItem
        fields = ['id', 'product_id', 'name', 'image', 'price', 'quantity', 'total_price']

    def get_total_price(self, obj):
        return f'${(obj.product.price * obj.quantity):.2f}'

class CartSerializer(serializers.ModelSerializer):
    items = CartItemSerializer(many=True, read_only=True)
    total_price = serializers.SerializerMethodField()

    class Meta:
        model = Cart
        fields = ['id', 'items', 'total_price']

    def get_total_price(self, obj):
        return f'${obj.total_price:.2f}'

class AddToCartSerializer(serializers.Serializer):
    product_id = serializers.IntegerField()
    quantity = serializers.IntegerField(min_value=1, default=1)

class UpdateCartItemSerializer(serializers.Serializer):
    quantity = serializers.IntegerField(min_value=1)

class BlogSerializer(serializers.ModelSerializer):
    created_at = serializers.SerializerMethodField()
    comment_count = serializers.IntegerField()

    class Meta:
        model = Blog
        fields = [
            'id', 'title', 'subtitle', 'content', 
            'image', 'author', 'created_at', 'comment_count'
        ]

    def get_created_at(self, obj):
        return obj.created_at.strftime('%B %d, %Y')

class ProductRecommendationSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    product_id = serializers.PrimaryKeyRelatedField(
        queryset=Product.objects.all(),
        write_only=True,
        source='product'
    )

    class Meta:
        model = ProductRecommendation
        fields = ['id', 'product', 'product_id', 'created_at']
        read_only_fields = ['id', 'created_at']
