from rest_framework import generics, filters, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend, FilterSet, NumberFilter, CharFilter
from django.shortcuts import get_object_or_404
from .models import (
    Product, Category, Size, Color, Leather, 
    Order, Cart, CartItem, OrderItem, Blog, ProductRecommendation
)

from django.db.models import Sum
from .serializers import (
    ProductSerializer, CategorySerializer, 
    SizeSerializer, ColorSerializer, LeatherSerializer,
    OrderSerializer, CartSerializer, CartItemSerializer,
    AddToCartSerializer, UpdateCartItemSerializer,
    CreateOrderSerializer, BlogSerializer, ProductRecommendationSerializer
)
from search.models import UserSearchHistory
from django.utils import timezone
from datetime import timedelta
from django.db.models import Q
import random

class ProductFilter(FilterSet):
    min_price = NumberFilter(field_name="price", lookup_expr='gte')
    max_price = NumberFilter(field_name="price", lookup_expr='lte')
    sizes = CharFilter(field_name='size__name', lookup_expr='in')
    colors = CharFilter(field_name='color__name', lookup_expr='in')
    leather_types = CharFilter(field_name='leather__name', lookup_expr='in')
    category = CharFilter(field_name='category__name')

    class Meta:
        model = Product
        fields = ['category', 'size', 'color', 'leather']

class ProductList(generics.ListAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = ProductFilter
    search_fields = ['name', 'description']
    ordering_fields = ['price', 'created_at', 'name']
    ordering = ['-created_at']  # Default ordering by latest
    
    

    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Handle size filter
        sizes = self.request.query_params.get('sizes', None)
        if sizes:
            size_list = sizes.split(',')
            queryset = queryset.filter(size__name__in=size_list)
        
        # Handle color filter
        colors = self.request.query_params.get('colors', None)
        if colors:
            color_list = colors.split(',')
            queryset = queryset.filter(color__name__in=color_list)
        
        # Handle leather types filter
        leather_types = self.request.query_params.get('leather_types', None)
        if leather_types:
            leather_list = leather_types.split(',')
            queryset = queryset.filter(leather__name__in=leather_list)

        # Track search history for authenticated users
        search_query = self.request.query_params.get('search', None)
        if search_query and self.request.user.is_authenticated:
            UserSearchHistory.objects.create(
                user=self.request.user,
                search_query=search_query
            )
        
        return queryset

class ProductDetail(generics.RetrieveAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class CategoryList(generics.ListAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class SizeList(generics.ListAPIView):
    queryset = Size.objects.all()
    serializer_class = SizeSerializer

class ColorList(generics.ListAPIView):
    queryset = Color.objects.all()
    serializer_class = ColorSerializer

class LeatherList(generics.ListAPIView):
    queryset = Leather.objects.all()
    serializer_class = LeatherSerializer

class OrderList(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = OrderSerializer

    def get_queryset(self):
        return Order.objects.filter(user=self.request.user).order_by('-created_at')

    def create(self, request, *args, **kwargs):
        # Get user's cart
        cart = get_object_or_404(Cart, user=request.user)
        if not cart.items.exists():
            return Response(
                {'error': 'Cart is empty'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Validate order data
        serializer = CreateOrderSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Create order
        order_data = serializer.validated_data
        order = Order.objects.create(
            user=request.user,
            **order_data
        )

        # Calculate totals
        total_price = 0
        shipping_cost = 10.00  # Example fixed shipping cost
        tax_rate = 0.10  # Example 10% tax rate

        # Create order items from cart items
        for cart_item in cart.items.all():
            # Create order item
            OrderItem.objects.create(
                order=order,
                product=cart_item.product,
                quantity=cart_item.quantity,
                price_at_time=cart_item.product.price
            )

            cart_item.product.save()

            total_price += cart_item.product.price * cart_item.quantity

        total_price = float(total_price)
        order.total_price = total_price
        order.shipping_cost = shipping_cost
        order.tax = total_price * tax_rate
        order.save()

        # Clear the cart
        cart.items.all().delete()

        return Response(
            OrderSerializer(order).data,
            status=status.HTTP_201_CREATED
        )

class OrderDetail(generics.RetrieveAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = OrderSerializer

    def get_queryset(self):
        return Order.objects.filter(user=self.request.user)

class OrderStatusUpdate(generics.UpdateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = OrderSerializer
    http_method_names = ['patch']

    def get_queryset(self):
        return Order.objects.filter(user=self.request.user)

    def patch(self, request, *args, **kwargs):
        order = self.get_object()
        new_status = request.data.get('status')
        
        if new_status not in dict(Order.STATUS_CHOICES):
            return Response(
                {'error': 'Invalid status'},
                status=status.HTTP_400_BAD_REQUEST
            )

        order.status = new_status
        order.save()

        return Response(OrderSerializer(order).data)

class CartView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        cart, created = Cart.objects.get_or_create(user=request.user)
        serializer = CartSerializer(cart)
        return Response(serializer.data)

    def post(self, request):
        serializer = AddToCartSerializer(data=request.data)
        if serializer.is_valid():
            product_id = serializer.validated_data['product_id']
            quantity = serializer.validated_data['quantity']
            
            product = get_object_or_404(Product, id=product_id)
            
            cart, created = Cart.objects.get_or_create(user=request.user)
            
            cart_item, created = CartItem.objects.get_or_create(
                cart=cart,
                product=product,
                defaults={'quantity': quantity}
            )
            
            if not created:
                cart_item.quantity += quantity
                cart_item.save()
            
            return Response(CartSerializer(cart).data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class CartItemView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, item_id):
        cart = get_object_or_404(Cart, user=request.user)
        cart_item = get_object_or_404(CartItem, id=item_id, cart=cart)
        serializer = CartItemSerializer(cart_item)
        return Response(serializer.data)

    def put(self, request, item_id):
        cart = get_object_or_404(Cart, user=request.user)
        cart_item = get_object_or_404(CartItem, id=item_id, cart=cart)
        
        serializer = UpdateCartItemSerializer(data=request.data)
        if serializer.is_valid():
            new_quantity = serializer.validated_data['quantity']

            cart_item.quantity = new_quantity
            cart_item.save()
            return Response(CartItemSerializer(cart_item).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, item_id):
        cart = get_object_or_404(Cart, user=request.user)
        cart_item = get_object_or_404(CartItem, id=item_id, cart=cart)
        cart_item.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class CartItemQuantityView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, item_id, action):
        cart = get_object_or_404(Cart, user=request.user)
        cart_item = get_object_or_404(CartItem, id=item_id, cart=cart)
        
        if action == 'increase':
            cart_item.quantity += 1
        elif action == 'decrease':
            if cart_item.quantity > 1:
                cart_item.quantity -= 1
            else:
                cart_item.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
        else:
            return Response(
                {'error': 'Invalid action. Use "increase" or "decrease".'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        cart_item.save()
        return Response(CartItemSerializer(cart_item).data)

class BlogList(generics.ListAPIView):
    queryset = Blog.objects.all()
    serializer_class = BlogSerializer
    pagination_class = None  # Disable pagination for blogs

class BlogDetail(generics.RetrieveAPIView):
    queryset = Blog.objects.all()
    serializer_class = BlogSerializer

class NewArrivals(ProductList):
    def get_queryset(self):
        # Get the base queryset from ProductList
        queryset = super().get_queryset()
        
        # Filter for products created in the last 10 days
        ten_days_ago = timezone.now() - timedelta(days=10)
        queryset = queryset.filter(created_at__gte=ten_days_ago)
        
        return queryset

class HomePageView(APIView):
    def get(self, request):
        # Get all categories
        categories = Category.objects.all()
        categories_data = CategorySerializer(categories, many=True).data

        # Get latest products for men and women
        latest_mens_products = Product.objects.filter(
            for_gender='male'
        ).order_by('-created_at')[:3]
        latest_womens_products = Product.objects.filter(
            for_gender='female'
        ).order_by('-created_at')[:3]

        # Get latest blog post
        latest_blog = Blog.objects.order_by('-created_at').first()

        # Get oldest products (first created)
        oldest_products = Product.objects.order_by('created_at')[:5]

        # Get latest products
        latest_products = Product.objects.order_by('-created_at')[:5]

        # Get random products
        all_products = list(Product.objects.all())
        random_products = random.sample(all_products, min(9, len(all_products)))

        # most sold product
        most_sold_product = OrderItem.objects.values('product').annotate(
            total_quantity=Sum('quantity')
        ).order_by('-total_quantity').first()
        
        if most_sold_product:
            most_sold_product = Product.objects.get(id=most_sold_product['product'])
        else:
            most_sold_product = Product.objects.first()

        response_data = {
            'categories': categories_data,
            'latest_mens_products': ProductSerializer(latest_mens_products, many=True).data,
            'latest_womens_products': ProductSerializer(latest_womens_products, many=True).data,
            'latest_blog': BlogSerializer(latest_blog).data if latest_blog else None,
            'oldest_products': ProductSerializer(oldest_products, many=True).data,
            'latest_products': ProductSerializer(latest_products, many=True).data,
            'random_products': ProductSerializer(random_products, many=True).data,
            'most_sold_item': ProductSerializer(most_sold_product).data,
        }

        return Response(response_data)

class ModifiersView(APIView):
    def get(self, request):
        sizes = Size.objects.all().order_by('name')
        leather_types = Leather.objects.all().order_by('name')
        colors = Color.objects.all().order_by('name')

        response_data = {
            'sizes': SizeSerializer(sizes, many=True).data,
            'leather_types': LeatherSerializer(leather_types, many=True).data,
            'colors': ColorSerializer(colors, many=True).data
        }
        
        return Response(response_data)

class ProductRecommendationView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        recommendations = ProductRecommendation.objects.filter(user=request.user)
        serializer = ProductRecommendationSerializer(recommendations, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = ProductRecommendationSerializer(data=request.data)
        if serializer.is_valid():
            # Check if recommendation already exists
            if ProductRecommendation.objects.filter(
                user=request.user,
                product=serializer.validated_data['product']
            ).exists():
                return Response(
                    {'error': 'Product already in recommendations'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            serializer.save(user=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
