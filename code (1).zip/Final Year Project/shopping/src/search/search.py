import numpy as np
import random
from collections import defaultdict
import pickle
import os

class QNetwork:
    def __init__(self, actions, alpha=0.1, gamma=0.95, epsilon=0.1):
        self.actions = actions
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.q_table = defaultdict(lambda: np.zeros(len(actions)))

    def choose_action(self, state):
        if np.random.rand() < self.epsilon:
            return random.choice(self.actions)
        q_values = self.q_table[state]
        return self.actions[np.argmax(q_values)]

    def update(self, state, action, reward, next_state):
        action_index = self.actions.index(action)
        next_q_values = self.q_table[next_state]
        td_target = reward + self.gamma * np.max(next_q_values)
        td_error = td_target - self.q_table[state][action_index]
        self.q_table[state][action_index] += self.alpha * td_error

    def get_top_actions(self, state, top_n=3):
        q_values = self.q_table[state]
        sorted_indices = np.argsort(q_values)[::-1][:top_n]
        return [self.actions[i] for i in sorted_indices]

    def save(self, path='q_table.pkl'):
        with open(path, 'wb') as f:
            pickle.dump(dict(self.q_table), f)

    def load(self, path='q_table.pkl'):
        if os.path.exists(path):
            with open(path, 'rb') as f:
                data = pickle.load(f)
                self.q_table = defaultdict(lambda: np.zeros(len(self.actions)), data)
