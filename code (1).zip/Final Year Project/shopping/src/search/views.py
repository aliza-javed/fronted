from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import UserSearchHistory
from .serializers import UserSearchHistorySerializer
from product.models import Product
from product.serializers import ProductSerializer
from search.until import load_q_network

class SearchView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        query = request.GET.get('query', '')
        user = request.user
        state = user.username

        if query:
            UserSearchHistory.objects.create(user=user, search_query=query)

        q_net = load_q_network()

        recommended_ids = q_net.get_top_actions(state, top_n=5)
        recommended_products = Product.objects.filter(id__in=recommended_ids)

        # Simulate reward
        for product in recommended_products:
            reward = 1.0 if query.lower() in product.name.lower() else 0.0
            q_net.update(state, product.id, reward, state)

        q_net.save()

        serialized = ProductSerializer(recommended_products, many=True)
        return Response(serialized.data)

class UserSearchHistoryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        history = UserSearchHistory.objects.filter(user=request.user)
        serializer = UserSearchHistorySerializer(history, many=True)
        return Response(serializer.data)
