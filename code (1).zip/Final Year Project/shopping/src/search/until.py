from product.models import Product
from .search import QNetwork

def load_q_network():
    product_ids = list(Product.objects.values_list('id', flat=True))
    q_net = QNetwork(actions=product_ids)
    q_net.load()
    return q_net
