# src/search/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('search/', views.SearchView.as_view(), name='search'),
    path('search-history/', views.UserSearchHistoryView.as_view(), name='search-history'),
]
