# src/search/serializers.py
from rest_framework import serializers
from .models import UserSearchHistory

class UserSearchHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = UserSearchHistory
        fields = ['id', 'search_query', 'created_at']
        read_only_fields = ['created_at'] 