# Leather Types API Documentation

## Get All Leather Types
Retrieves a list of all available leather types.

### Endpoint
```
GET /api/leather-types/
```

### Response Schema
```json
{
  "count": "integer",
  "next": "string (URL) or null",
  "previous": "string (URL) or null",
  "results": [
    {
      "id": "integer",
      "name": "string",
      "description": "string",
      "characteristics": "string"
    }
  ]
}
```

### Example Response
```json
{
  "count": 3,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": 1,
      "name": "Full Grain",
      "description": "Highest quality leather with natural grain",
      "characteristics": "Durable, ages beautifully, shows natural markings"
    },
    {
      "id": 2,
      "name": "Top Grain",
      "description": "Second highest quality leather",
      "characteristics": "Smooth surface, consistent appearance, good durability"
    },
    {
      "id": 3,
      "name": "Genuine Leather",
      "description": "Real leather with processed surface",
      "characteristics": "Affordable, consistent look, moderate durability"
    }
  ]
}
```

### Notes
- Results are paginated (10 items per page)
- Results are ordered alphabetically by name
- Leather types are used for product filtering
- Each leather type has a unique name
- The API supports pagination using `next` and `previous` URLs
- Characteristics describe the key features of each leather type 