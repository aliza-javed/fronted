# Categories API Documentation

## 1. Get All Categories
Retrieves a list of all product categories.

### Endpoint
```
GET /api/categories/
```

### Response Schema
```json
[
  {
    "id": "integer",
    "name": "string",
    "image": "string (URL)"
  }
]
```

### Example Response
```json
[
  {
    "id": 1,
    "name": "Wallets",
    "image": "http://example.com/media/categories/wallets.jpg"
  },
  {
    "id": 2,
    "name": "Belts",
    "image": "http://example.com/media/categories/belts.jpg"
  }
]
```

### Notes
- Categories are returned in alphabetical order by name
- The image field contains the full URL to the category image
- Categories are used to organize products and can be used for filtering

## 2. Categories in Homepage API
Category data is also included in the homepage API response.

### Endpoint
```
GET /api/
```

### Response Schema (Categories Part)
```json
{
  "categories": [
    {
      "id": "integer",
      "name": "string",
      "image": "string (URL)"
    }
  ]
}
```

### Example Response (Categories Part)
```json
{
  "categories": [
    {
      "id": 1,
      "name": "Wallets",
      "image": "http://example.com/media/categories/wallets.jpg"
    }
  ]
}
```

### Notes
- Categories in the homepage API have the same structure as the main categories endpoint
- Categories are used for navigation and product filtering
- Each category has a unique image for visual representation 