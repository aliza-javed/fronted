# Cart API Documentation

## 1. Get Cart
Retrieves the current user's cart with all items.

### Endpoint
```
GET /api/cart/
```

### Authentication
- Requires JWT authentication
- Token must be included in the Authorization header

### Response Schema
```json
{
  "id": "integer",
  "items": [
    {
      "id": "integer",
      "product": {
        "id": "integer",
        "name": "string",
        "image": "string (URL)",
        "price": "string (format: '$XX.XX')"
      },
      "quantity": "integer",
      "total_price": "string (format: '$XX.XX')"
    }
  ],
  "total_price": "string (format: '$XX.XX')"
}
```

### Example Response
```json
{
  "id": 1,
  "items": [
    {
      "id": 1,
      "product": {
        "id": 1,
        "name": "Classic Leather Wallet",
        "image": "http://example.com/media/products/wallet1.jpg",
        "price": "$99.99"
      },
      "quantity": 2,
      "total_price": "$199.98"
    }
  ],
  "total_price": "$199.98"
}
```

### Error Responses

#### 401 Unauthorized
```json
{
  "detail": "Authentication credentials were not provided."
}
```

## 2. Add to Cart
Adds a product to the cart or updates its quantity if it already exists.

### Endpoint
```
POST /api/cart/
```

### Authentication
- Requires JWT authentication
- Token must be included in the Authorization header

### Request Body
```json
{
  "product_id": "integer",
  "quantity": "integer (min: 1)"
}
```

### Example Request
```json
{
  "product_id": 1,
  "quantity": 2
}
```

### Response Schema
Same as Get Cart response

### Error Responses

#### 400 Bad Request
```json
{
  "error": "Not enough stock available"
}
```
Occurs when requested quantity exceeds available stock.

#### 404 Not Found
```json
{
  "detail": "Not found."
}
```
Occurs when the product doesn't exist.

## 3. Update Cart Item
Updates the quantity of a specific cart item.

### Endpoint
```
PUT /api/cart/items/{item_id}/
```

### Authentication
- Requires JWT authentication
- Token must be included in the Authorization header

### URL Parameters
| Parameter | Type   | Description |
|-----------|--------|-------------|
| item_id   | integer| The unique identifier of the cart item |

### Request Body
```json
{
  "quantity": "integer (min: 1)"
}
```

### Example Request
```json
{
  "quantity": 3
}
```

### Response Schema
```json
{
  "id": "integer",
  "product": {
    "id": "integer",
    "name": "string",
    "image": "string (URL)",
    "price": "string (format: '$XX.XX')"
  },
  "quantity": "integer",
  "total_price": "string (format: '$XX.XX')"
}
```

### Error Responses

#### 400 Bad Request
```json
{
  "error": "Not enough stock available"
}
```
Occurs when requested quantity exceeds available stock.

#### 404 Not Found
```json
{
  "detail": "Not found."
}
```
Occurs when the cart item doesn't exist.

## 4. Increase/Decrease Cart Item Quantity
Increases or decreases the quantity of a cart item by 1.

### Endpoint
```
POST /api/cart/items/{item_id}/{action}/
```

### Authentication
- Requires JWT authentication
- Token must be included in the Authorization header

### URL Parameters
| Parameter | Type   | Description |
|-----------|--------|-------------|
| item_id   | integer| The unique identifier of the cart item |
| action    | string | Either 'increase' or 'decrease' |

### Response Schema
Same as Update Cart Item response

### Error Responses

#### 400 Bad Request
```json
{
  "error": "Not enough stock available"
}
```
Occurs when increasing quantity exceeds available stock.

```json
{
  "error": "Quantity cannot be less than 1"
}
```
Occurs when trying to decrease quantity below 1.

#### 404 Not Found
```json
{
  "detail": "Not found."
}
```
Occurs when the cart item doesn't exist.

## 5. Remove Cart Item
Removes an item from the cart.

### Endpoint
```
DELETE /api/cart/items/{item_id}/
```

### Authentication
- Requires JWT authentication
- Token must be included in the Authorization header

### URL Parameters
| Parameter | Type   | Description |
|-----------|--------|-------------|
| item_id   | integer| The unique identifier of the cart item |

### Response
- 204 No Content on successful deletion

### Error Responses

#### 404 Not Found
```json
{
  "detail": "Not found."
}
```
Occurs when the cart item doesn't exist.

### Notes
- All price fields are formatted as strings with dollar sign and two decimal places
- Stock validation is performed for all quantity updates
- Cart items are automatically removed when quantity reaches 0
- The cart is user-specific and requires authentication
- All endpoints return appropriate HTTP status codes
- Error responses include descriptive messages 