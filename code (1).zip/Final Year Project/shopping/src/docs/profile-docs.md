# Profile API Documentation

## Get User Profile
Retrieves the profile information of the currently logged-in user.

### Endpoint
```
GET /api/auth/profile/
```

### Authentication
- JWT Authentication required
- User must be logged in

### Response Schema
```json
{
  "id": "integer",
  "username": "string",
  "email": "string",
  "first_name": "string",
  "last_name": "string",
  "date_joined": "string (format: 'YYYY-MM-DD HH:mm:ss')",
  "last_login": "string (format: 'YYYY-MM-DD HH:mm:ss')"
}
```

### Example Response
```json
{
  "id": 1,
  "username": "john_doe",
  "email": "john@example.com",
  "first_name": "John",
  "last_name": "Doe",
  "date_joined": "2025-03-30 14:30:00",
  "last_login": "2025-03-30 15:45:00"
}
```

### Error Responses
- `401 Unauthorized`: If user is not authenticated
- `403 Forbidden`: If user doesn't have permission to view profile

### Notes
- All fields except `id`, `date_joined`, and `last_login` can be updated
- The `last_login` field shows the most recent login timestamp
- `date_joined` shows when the user account was created
- Email is required and must be unique
- Username is required and must be unique
- Timestamps are in UTC timezone 