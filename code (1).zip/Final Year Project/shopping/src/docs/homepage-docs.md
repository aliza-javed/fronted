# Homepage API Documentation

## Get Homepage Data
Retrieves all data needed for the homepage, including categories, latest products, blog posts, and more.

### Endpoint
```
GET /api/
```

### Response Schema
```json
{
  "categories": [
    {
      "id": "integer",
      "name": "string",
      "image": "string (URL)"
    }
  ],
  "latest_mens_products": [
    {
      "id": "integer",
      "name": "string",
      "price": "string (format: '$XX.XX')",
      "image": "string (URL)",
      "category": {
        "id": "integer",
        "name": "string",
        "image": "string (URL)"
      }
    }
  ],
  "latest_womens_products": [
    // Same structure as latest_mens_products
  ],
  "latest_blog": {
    "id": "integer",
    "title": "string",
    "subtitle": "string",
    "content": "string",
    "image": "string (URL)",
    "author": "string",
    "created_at": "string (format: 'Month DD, YYYY')",
    "comment_count": "integer"
  },
  "oldest_products": [
    // Same structure as latest_mens_products
  ],
  "latest_products": [
    // Same structure as latest_mens_products
  ],
  "random_products": [
    // Same structure as latest_mens_products
  ]
}
```

### Example Response
```json
{
  "categories": [
    {
      "id": 1,
      "name": "Wallets",
      "image": "http://example.com/media/categories/wallets.jpg"
    }
  ],
  "latest_mens_products": [
    {
      "id": 1,
      "name": "Classic Leather Wallet",
      "price": "$99.99",
      "image": "http://example.com/media/products/wallet1.jpg",
      "category": {
        "id": 1,
        "name": "Wallets",
        "image": "http://example.com/media/categories/wallets.jpg"
      }
    }
  ],
  "latest_womens_products": [
    {
      "id": 2,
      "name": "Designer Handbag",
      "price": "$199.99",
      "image": "http://example.com/media/products/handbag1.jpg",
      "category": {
        "id": 2,
        "name": "Bags",
        "image": "http://example.com/media/categories/bags.jpg"
      }
    }
  ],
  "latest_blog": {
    "id": 1,
    "title": "Sustainability and Ethics",
    "subtitle": "The Journey to Sustainable Leather",
    "content": "Discover how sustainable leather is reshaping the fashion industry...",
    "image": "http://example.com/media/blogs/blog1.jpg",
    "author": "wpthemes",
    "created_at": "March 30, 2025",
    "comment_count": 0
  },
  "oldest_products": [
    // 5 oldest products
  ],
  "latest_products": [
    // 5 latest products
  ],
  "random_products": [
    // 9 random products
  ]
}
```

### Notes
- `latest_mens_products` and `latest_womens_products` contain 3 products each
- `oldest_products` and `latest_products` contain 5 products each
- `random_products` contains 9 random products
- The `latest_blog` field will be `null` if there are no blog posts
- All product lists maintain the same structure
- Categories are used for navigation and product filtering
- All images are returned as full URLs
- Prices are formatted with dollar sign and two decimal places 