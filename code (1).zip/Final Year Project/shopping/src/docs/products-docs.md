# Products API Documentation

## 1. Get All Products
Retrieves a paginated list of all products with filtering, sorting, and search capabilities.

### Endpoint
```
GET /api/products/
```

### Query Parameters
| Parameter | Type    | Description | Example |
|-----------|---------|-------------|---------|
| search    | string  | Search in name and description | `?search=leather` |
| category  | integer | Filter by category ID | `?category=1` |
| size      | integer | Filter by size ID | `?size=2` |
| color     | integer | Filter by color ID | `?color=3` |
| leather   | integer | Filter by leather type ID | `?leather=1` |
| min_price | decimal | Minimum price filter | `?min_price=50.00` |
| max_price | decimal | Maximum price filter | `?max_price=200.00` |
| for_gender| string  | Filter by gender (male/female) | `?for_gender=male` |
| ordering  | string  | Sort by field (- for descending) | `?ordering=-price` |
| page      | integer | Page number for pagination | `?page=2` |

### Response Schema
```json
{
  "count": "integer (total number of items)",
  "next": "string (URL for next page) or null",
  "previous": "string (URL for previous page) or null",
  "results": [
    {
      "id": "integer",
      "name": "string",
      "description": "string",
      "price": "string (format: '$XX.XX')",
      "image": "string (URL)",
      "category": {
        "id": "integer",
        "name": "string",
        "image": "string (URL)"
      },
      "stock": "integer",
      "size": {
        "id": "integer",
        "name": "string"
      },
      "color": {
        "id": "integer",
        "name": "string"
      },
      "leather": {
        "id": "integer",
        "name": "string"
      },
      "for_gender": "string (male/female/null)",
      "created_at": "string (ISO datetime)",
      "recommended_products": [
        {
          "id": "integer",
          "name": "string",
          "price": "string (format: '$XX.XX')",
          "image": "string (URL)"
        }
      ]
    }
  ]
}
```

### Example Response
```json
{
  "count": 50,
  "next": "http://api/products/?page=2",
  "previous": null,
  "results": [
    {
      "id": 1,
      "name": "Classic Leather Wallet",
      "description": "Handcrafted full-grain leather wallet...",
      "price": "$99.99",
      "image": "http://example.com/media/products/wallet1.jpg",
      "category": {
        "id": 1,
        "name": "Wallets",
        "image": "http://example.com/media/categories/wallets.jpg"
      },
      "stock": 10,
      "size": {
        "id": 1,
        "name": "Medium"
      },
      "color": {
        "id": 1,
        "name": "Black"
      },
      "leather": {
        "id": 1,
        "name": "Full-Grain Leather"
      },
      "for_gender": "male",
      "created_at": "2024-03-14T10:00:00Z",
      "recommended_products": [
        {
          "id": 2,
          "name": "Leather Card Holder",
          "price": "$49.99",
          "image": "http://example.com/media/products/cardholder1.jpg"
        }
      ]
    }
  ]
}
```

### Notes
- Default page size is 10 items
- Search is case-insensitive
- Multiple filters can be combined
- Valid ordering fields: price, created_at, name
- For authenticated users, search queries are saved in search history

## 2. Get Single Product
Retrieves details of a specific product.

### Endpoint
```
GET /api/products/{id}/
```

### URL Parameters
| Parameter | Type   | Description |
|-----------|--------|-------------|
| id        | integer| The unique identifier of the product |

### Response Schema
```json
{
  "id": "integer",
  "name": "string",
  "description": "string",
  "price": "string (format: '$XX.XX')",
  "image": "string (URL)",
  "category": {
    "id": "integer",
    "name": "string",
    "image": "string (URL)"
  },
  "stock": "integer",
  "size": {
    "id": "integer",
    "name": "string"
  },
  "color": {
    "id": "integer",
    "name": "string"
  },
  "leather": {
    "id": "integer",
    "name": "string"
  },
  "for_gender": "string (male/female/null)",
  "created_at": "string (ISO datetime)",
  "recommended_products": [
    {
      "id": "integer",
      "name": "string",
      "price": "string (format: '$XX.XX')",
      "image": "string (URL)"
    }
  ]
}
```

### Example Response
```json
{
  "id": 1,
  "name": "Classic Leather Wallet",
  "description": "Handcrafted full-grain leather wallet with multiple card slots and bill compartment...",
  "price": "$99.99",
  "image": "http://example.com/media/products/wallet1.jpg",
  "category": {
    "id": 1,
    "name": "Wallets",
    "image": "http://example.com/media/categories/wallets.jpg"
  },
  "stock": 10,
  "size": {
    "id": 1,
    "name": "Medium"
  },
  "color": {
    "id": 1,
    "name": "Black"
  },
  "leather": {
    "id": 1,
    "name": "Full-Grain Leather"
  },
  "for_gender": "male",
  "created_at": "2024-03-14T10:00:00Z",
  "recommended_products": [
    {
      "id": 2,
      "name": "Leather Card Holder",
      "price": "$49.99",
      "image": "http://example.com/media/products/cardholder1.jpg"
    }
  ]
}
```

### Error Responses

#### 404 Not Found
```json
{
  "detail": "Not found."
}
```
Occurs when the product with the specified ID doesn't exist.

## 3. New Arrivals
Retrieves products created within the last 10 days.

### Endpoint
```
GET /api/products/new-arrivals/
```

### Query Parameters
Same as Get All Products endpoint

### Response Schema
Same as Get All Products endpoint

### Notes
- Only returns products created within the last 10 days
- Inherits all filtering, sorting, and search capabilities from the main products endpoint
- Maintains pagination

## 4. Products in Homepage API
Product data is also included in the homepage API response.

### Endpoint
```
GET /api/
```

### Response Schema (Products Part)
```json
{
  "latest_mens_products": [
    {
      "id": "integer",
      "name": "string",
      "price": "string (format: '$XX.XX')",
      "image": "string (URL)",
      "category": {
        "id": "integer",
        "name": "string",
        "image": "string (URL)"
      }
    }
  ],
  "latest_womens_products": [
    // Same structure as latest_mens_products
  ],
  "oldest_products": [
    // Same structure as latest_mens_products
  ],
  "latest_products": [
    // Same structure as latest_mens_products
  ],
  "random_products": [
    // Same structure as latest_mens_products
  ]
}
```

### Notes
- `latest_mens_products` and `latest_womens_products` contain 3 products each
- `oldest_products` and `latest_products` contain 5 products each
- `random_products` contains 9 random products
- All product lists maintain the same structure as the main product response 