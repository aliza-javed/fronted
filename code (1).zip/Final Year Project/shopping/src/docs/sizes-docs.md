# Sizes API Documentation

## Get All Sizes
Retrieves a list of all available product sizes.

### Endpoint
```
GET /api/sizes/
```

### Response Schema
```json
{
  "count": "integer",
  "next": "string (URL) or null",
  "previous": "string (URL) or null",
  "results": [
    {
      "id": "integer",
      "name": "string",
      "description": "string"
    }
  ]
}
```

### Example Response
```json
{
  "count": 3,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": 1,
      "name": "Small",
      "description": "Small size products"
    },
    {
      "id": 2,
      "name": "Medium",
      "description": "Medium size products"
    },
    {
      "id": 3,
      "name": "Large",
      "description": "Large size products"
    }
  ]
}
```

### Notes
- Results are paginated (10 items per page)
- Results are ordered alphabetically by name
- Sizes are used for product filtering
- Each size has a unique name
- The API supports pagination using `next` and `previous` URLs 