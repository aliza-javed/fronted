# Authentication API Documentation

## Register User
Creates a new user account.

### Endpoint
```
POST /api/auth/register/
```

### Request Schema
```json
{
  "username": "string",
  "email": "string",
  "password": "string",
  "confirm_password": "string"
}
```

### Example Request
```json
{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "securepassword123",
  "confirm_password": "securepassword123"
}
```

### Response Schema
```json
{
  "message": "string"
}
```

### Example Response
```json
{
  "message": "User created successfully"
}
```

### Error Responses
- `400 Bad Request`: If validation fails
  - Passwords don't match
  - Password doesn't meet requirements
  - Username/email already exists
  - Required fields missing

## Login User
Authenticates a user and returns JWT tokens.

### Endpoint
```
POST /api/auth/login/
```

### Request Schema
```json
{
  "username": "string",
  "password": "string"
}
```

### Example Request
```json
{
  "username": "john_doe",
  "password": "securepassword123"
}
```

### Response Schema
```json
{
  "access": "string (JWT token)",
  "refresh": "string (JWT refresh token)"
}
```

### Example Response
```json
{
  "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
}
```

### Error Responses
- `401 Unauthorized`: If credentials are invalid
- `400 Bad Request`: If required fields are missing

## Refresh Token
Get a new access token using a refresh token.

### Endpoint
```
POST /api/auth/token/refresh/
```

### Request Schema
```json
{
  "refresh": "string (JWT refresh token)"
}
```

### Example Request
```json
{
  "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
}
```

### Response Schema
```json
{
  "access": "string (JWT token)"
}
```

### Example Response
```json
{
  "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
}
```

### Error Responses
- `401 Unauthorized`: If refresh token is invalid or expired
- `400 Bad Request`: If refresh token is missing

### Notes
- JWT tokens are used for authentication
- Access tokens expire after 5 minutes
- Refresh tokens expire after 24 hours
- Store refresh tokens securely
- Include access token in Authorization header for protected endpoints
- Format: `Authorization: Bearer <access_token>` 