# Contact Us API Documentation

## 1. Submit Contact Form
Submits a contact form message.

### Endpoint
```
POST /api/contact/submit/
```

### Request Body
```json
{
  "name": "string (max length: 100)",
  "email": "string (valid email format)",
  "contact": "string (max length: 100, optional)",
  "message": "string"
}
```

### Example Request
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "contact": "+1234567890",
  "message": "I would like to inquire about your leather products. Do you offer custom designs?"
}
```

### Response Schema

#### Success Response (201 Created)
```json
{
  "message": "S