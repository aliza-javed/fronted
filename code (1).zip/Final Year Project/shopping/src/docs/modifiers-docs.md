# Modifiers API Documentation

## Get All Modifiers
Retrieves all product modifiers (sizes, leather types, and colors) in a single response.

### Endpoint
```
GET /api/modifiers/
```

### Response Schema
```json
{
  "sizes": [
    {
      "id": "integer",
      "name": "string",
      "description": "string"
    }
  ],
  "leather_types": [
    {
      "id": "integer",
      "name": "string",
      "description": "string",
      "characteristics": "string"
    }
  ],
  "colors": [
    {
      "id": "integer",
      "name": "string",
      "hex_code": "string",
      "description": "string"
    }
  ]
}
```

### Example Response
```json
{
  "sizes": [
    {
      "id": 1,
      "name": "Small",
      "description": "Small size products"
    },
    {
      "id": 2,
      "name": "Medium",
      "description": "Medium size products"
    },
    {
      "id": 3,
      "name": "Large",
      "description": "Large size products"
    }
  ],
  "leather_types": [
    {
      "id": 1,
      "name": "Full Grain",
      "description": "Highest quality leather with natural grain",
      "characteristics": "Durable, ages beautifully, shows natural markings"
    },
    {
      "id": 2,
      "name": "Top Grain",
      "description": "Second highest quality leather",
      "characteristics": "Smooth surface, consistent appearance, good durability"
    }
  ],
  "colors": [
    {
      "id": 1,
      "name": "Black",
      "hex_code": "#000000",
      "description": "Classic black color"
    },
    {
      "id": 2,
      "name": "Brown",
      "hex_code": "#8B4513",
      "description": "Rich brown color"
    }
  ]
}
```

### Notes
- All lists are ordered alphabetically by name
- Sizes are used for product filtering and selection
- Leather types describe the quality and characteristics of the leather
- Colors include both name and hex code for display purposes
- This endpoint combines three separate endpoints into one for efficiency
- No pagination is applied to any of the lists
- Each modifier type maintains its own unique ID system 