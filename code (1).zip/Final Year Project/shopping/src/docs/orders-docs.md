# Orders API Documentation

## 1. Get Order List
Retrieves a list of all orders for the authenticated user.

### Endpoint
```
GET /api/orders/
```

### Authentication
- Requires JWT authentication
- Token must be included in the Authorization header

### Response Schema
```json
[
  {
    "id": "integer",
    "order_number": "string (format: 'ORD-YYYYMMDD-XXX')",
    "created_at": "string (ISO datetime)",
    "updated_at": "string (ISO datetime)",
    "customer_name": "string",
    "customer_email": "string",
    "customer_phone": "string",
    "shipping_address": "string",
    "shipping_city": "string",
    "shipping_state": "string",
    "shipping_country": "string",
    "shipping_zip_code": "string",
    "status": "string (pending/processing/shipped/delivered/cancelled)",
    "status_display": "string",
    "payment_status": "string (pending/paid/failed/refunded)",
    "payment_status_display": "string",
    "payment_method": "string (credit_card/debit_card/paypal/bank_transfer)",
    "payment_method_display": "string",
    "total_price": "string (format: '$XX.XX')",
    "shipping_cost": "string (format: '$XX.XX')",
    "tax": "string (format: '$XX.XX')",
    "discount": "string (format: '$XX.XX')",
    "final_price": "string (format: '$XX.XX')",
    "notes": "string or null",
    "tracking_number": "string or null",
    "estimated_delivery": "string (YYYY-MM-DD) or null",
    "items": [
      {
        "id": "integer",
        "product": {
          "id": "integer",
          "name": "string",
          "image": "string (URL)",
          "price": "string (format: '$XX.XX')"
        },
        "quantity": "integer",
        "price_at_time": "string (format: '$XX.XX')",
        "total_price": "string (format: '$XX.XX')"
      }
    ]
  }
]
```

### Example Response
```json
[
  {
    "id": 1,
    "order_number": "ORD-20240314-001",
    "created_at": "2024-03-14T10:00:00Z",
    "updated_at": "2024-03-14T10:00:00Z",
    "customer_name": "John Doe",
    "customer_email": "john@example.com",
    "customer_phone": "1234567890",
    "shipping_address": "123 Main St",
    "shipping_city": "New York",
    "shipping_state": "NY",
    "shipping_country": "USA",
    "shipping_zip_code": "10001",
    "status": "pending",
    "status_display": "Pending",
    "payment_status": "pending",
    "payment_status_display": "Pending",
    "payment_method": "credit_card",
    "payment_method_display": "Credit Card",
    "total_price": "$199.98",
    "shipping_cost": "$10.00",
    "tax": "$20.00",
    "discount": "$0.00",
    "final_price": "$229.98",
    "notes": "Please deliver in the evening",
    "tracking_number": null,
    "estimated_delivery": "2024-03-20",
    "items": [
      {
        "id": 1,
        "product": {
          "id": 1,
          "name": "Classic Leather Wallet",
          "image": "http://example.com/media/products/wallet1.jpg",
          "price": "$99.99"
        },
        "quantity": 2,
        "price_at_time": "$99.99",
        "total_price": "$199.98"
      }
    ]
  }
]
```

### Error Responses

#### 401 Unauthorized
```json
{
  "detail": "Authentication credentials were not provided."
}
```

## 2. Create Order
Creates a new order from the current user's cart.

### Endpoint
```
POST /api/orders/
```

### Authentication
- Requires JWT authentication
- Token must be included in the Authorization header

### Request Body
```json
{
  "customer_name": "string",
  "customer_email": "string",
  "customer_phone": "string",
  "shipping_address": "string",
  "shipping_city": "string",
  "shipping_state": "string",
  "shipping_country": "string",
  "shipping_zip_code": "string",
  "payment_method": "string (credit_card/debit_card/paypal/bank_transfer)",
  "notes": "string (optional)"
}
```

### Example Request
```json
{
  "customer_name": "John Doe",
  "customer_email": "john@example.com",
  "customer_phone": "1234567890",
  "shipping_address": "123 Main St",
  "shipping_city": "New York",
  "shipping_state": "NY",
  "shipping_country": "USA",
  "shipping_zip_code": "10001",
  "payment_method": "credit_card",
  "notes": "Please deliver in the evening"
}
```

### Response Schema
Same as Get Order List response schema (single order)

### Error Responses

#### 400 Bad Request
```json
{
  "error": "Cart is empty"
}
```
Occurs when trying to create an order with an empty cart.

```json
{
  "error": "Not enough stock for {product_name}"
}
```
Occurs when any product in the cart has insufficient stock.

#### 401 Unauthorized
```json
{
  "detail": "Authentication credentials were not provided."
}
```

## 3. Get Order Detail
Retrieves details of a specific order.

### Endpoint
```
GET /api/orders/{id}/
```

### Authentication
- Requires JWT authentication
- Token must be included in the Authorization header

### URL Parameters
| Parameter | Type   | Description |
|-----------|--------|-------------|
| id        | integer| The unique identifier of the order |

### Response Schema
Same as Get Order List response schema (single order)

### Error Responses

#### 404 Not Found
```json
{
  "detail": "Not found."
}
```
Occurs when the order doesn't exist or doesn't belong to the authenticated user.

## 4. Update Order Status
Updates the status of a specific order.

### Endpoint
```
PATCH /api/orders/{id}/status/
```

### Authentication
- Requires JWT authentication
- Token must be included in the Authorization header

### URL Parameters
| Parameter | Type   | Description |
|-----------|--------|-------------|
| id        | integer| The unique identifier of the order |

### Request Body
```json
{
  "status": "string (pending/processing/shipped/delivered/cancelled)"
}
```

### Example Request
```json
{
  "status": "shipped"
}
```

### Response Schema
Same as Get Order List response schema (single order)

### Error Responses

#### 400 Bad Request
```json
{
  "error": "Invalid status"
}
```
Occurs when an invalid status is provided.

#### 404 Not Found
```json
{
  "detail": "Not found."
}
```
Occurs when the order doesn't exist or doesn't belong to the authenticated user.

### Notes
- All price fields are formatted as strings with dollar sign and two decimal places
- Order numbers are automatically generated in the format 'ORD-YYYYMMDD-XXX'
- Orders are created from the current user's cart, which is cleared after order creation
- Stock is automatically updated when an order is created
- Shipping cost is fixed at $10.00
- Tax rate is 10% of the total price
- Orders can only be viewed and managed by the user who created them
- Status updates are restricted to valid status values
- All timestamps are in ISO 8601 format
- Estimated delivery date is calculated based on the order date and shipping method 