# Blog API Documentation

## 1. Get All Blogs
Retrieves a list of all blog posts.

### Endpoint
```
GET /api/blogs/
```

### Query Parameters
None

### Response Schema
```json
[
  {
    "id": "integer",
    "title": "string",
    "subtitle": "string",
    "content": "string",
    "image": "string (URL)",
    "author": "string",
    "created_at": "string (format: 'Month DD, YYYY')",
    "comment_count": "integer"
  }
]
```

### Example Response
```json
[
  {
    "id": 1,
    "title": "Sustainability and Ethics",
    "subtitle": "The Journey to Sustainable Leather: What You Should Know",
    "content": "Discover how sustainable leather is reshaping the fashion industry...",
    "image": "http://example.com/media/blogs/blog1.jpg",
    "author": "wpthemes",
    "created_at": "March 30, 2025",
    "comment_count": 0
  }
]
```

### Notes
- The response is not paginated
- Blogs are ordered by creation date (newest first)
- The `created_at` field is formatted as "Month DD, YYYY"
- The `image` field contains the full URL to the blog image
- The `comment_count` field shows the total number of comments on the blog

## 2. Get Single Blog
Retrieves details of a specific blog post.

### Endpoint
```
GET /api/blogs/{id}/
```

### URL Parameters
| Parameter | Type   | Description                    |
|-----------|--------|--------------------------------|
| id        | integer| The unique identifier of the blog |

### Response Schema
```json
{
  "id": "integer",
  "title": "string",
  "subtitle": "string",
  "content": "string",
  "image": "string (URL)",
  "author": "string",
  "created_at": "string (format: 'Month DD, YYYY')",
  "comment_count": "integer"
}
```

### Example Response
```json
{
  "id": 1,
  "title": "Sustainability and Ethics",
  "subtitle": "The Journey to Sustainable Leather: What You Should Know",
  "content": "Discover how sustainable leather is reshaping the fashion industry—from eco-friendly hide sourcing and vegetable tanning methods to global certifications that ensure ethical practices. Learn the key steps you can look for when choosing leather goods that protect both people and the planet.",
  "image": "http://example.com/media/blogs/blog1.jpg",
  "author": "wpthemes",
  "created_at": "March 30, 2025",
  "comment_count": 0
}
```

### Error Responses

#### 404 Not Found
```json
{
  "detail": "Not found."
}
```
Occurs when the blog with the specified ID doesn't exist.

### Notes
- The `created_at` field is formatted as "Month DD, YYYY"
- The `image` field contains the full URL to the blog image
- The `comment_count` field shows the total number of comments on the blog
- The `content` field contains the full blog post content

## 3. Blog in Homepage API
Blog data is also included in the homepage API response.

### Endpoint
```
GET /api/
```

### Response Schema (Blog Part)
```json
{
  "latest_blog": {
    "id": "integer",
    "title": "string",
    "subtitle": "string",
    "content": "string",
    "image": "string (URL)",
    "author": "string",
    "created_at": "string (format: 'Month DD, YYYY')",
    "comment_count": "integer"
  }
}
```

### Example Response (Blog Part)
```json
{
  "latest_blog": {
    "id": 1,
    "title": "Sustainability and Ethics",
    "subtitle": "The Journey to Sustainable Leather: What You Should Know",
    "content": "Discover how sustainable leather is reshaping the fashion industry...",
    "image": "http://example.com/media/blogs/blog1.jpg",
    "author": "wpthemes",
    "created_at": "March 30, 2025",
    "comment_count": 0
  }
}
```

### Notes
- The `latest_blog` field will be `null` if there are no blog posts
- This endpoint returns only the most recent blog post
- The response format is the same as the single blog endpoint 