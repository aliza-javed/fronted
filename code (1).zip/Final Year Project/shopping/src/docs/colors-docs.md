# Colors API Documentation

## Get All Colors
Retrieves a list of all available product colors.

### Endpoint
```
GET /api/colors/
```

### Response Schema
```json
{
  "count": "integer",
  "next": "string (URL) or null",
  "previous": "string (URL) or null",
  "results": [
    {
      "id": "integer",
      "name": "string",
      "hex_code": "string",
      "description": "string"
    }
  ]
}
```

### Example Response
```json
{
  "count": 4,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": 1,
      "name": "Black",
      "hex_code": "#000000",
      "description": "Classic black color"
    },
    {
      "id": 2,
      "name": "Brown",
      "hex_code": "#8B4513",
      "description": "Rich brown color"
    },
    {
      "id": 3,
      "name": "Tan",
      "hex_code": "#D2B48C",
      "description": "Light tan color"
    },
    {
      "id": 4,
      "name": "Burgundy",
      "hex_code": "#800020",
      "description": "Deep burgundy color"
    }
  ]
}
```

### Notes
- Results are paginated (10 items per page)
- Results are ordered alphabetically by name
- Colors are used for product filtering
- Each color has a unique name and hex code
- The API supports pagination using `next` and `previous` URLs
- Hex codes are in standard 6-digit format 