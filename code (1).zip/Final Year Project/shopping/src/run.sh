#!/bin/env bash

python manage.py collectstatic --noinput
python3 manage.py makemigrations
python3 manage.py migrate --no-input
python3 manage.py load_initial_data

exec "$@"