import React from "react";
import aboutImg from "../webassets/imagevdds-1.jpg";
import promoImg from "../webassets/Dark-Minimal-Casual-Fashion-Collection-Shop-Now-Your-Story-1.jpg";
import { useNavigate } from 'react-router-dom';
import { useHomepage } from "../contexts/HomepageContext";
import { getMediaUrl } from "../helpers";
import { HomepageBlog } from "../services/types/homepage.types";


const LeftSidebar: React.FC = () => {
  const { data } = useHomepage()

  const miniCards = data?.oldest_products || []
  const latest_blog = data?.latest_blog || {} as HomepageBlog
  const navigate = useNavigate();

  return (
    <div className="w-full lg:w-1/5 px-2 mb-6 mt-14 lg:mb-0">
      {/* About Card */}
      <div className="border border-gray-300 bg-white shadow-md overflow-hidden w-full lg:w-[280px] mx-auto mb-6">
        <img
          src={aboutImg}
          alt="About Us"
          className="w-full h-72 object-cover cursor-pointer"
          onClick={() => navigate('/about-us')}
        />
        <div className="p-4">
          <h2 className="text-xl font-bold mb-2">About Us</h2>
          <p className="text-gray-700 mb-4 text-md leading-relaxed">
            We are Aliza Javed and Muhammad Asim, the founders of an online recommendation engine that blends quality,
            style, and smart technology. Our products are made from 100% genuine leather, designed to be both elegant and long-lasting.
            As a modern online store, we offer more than just fashion — our website uses a smart recommendation engine that remembers what
            you searched, so the next time you visit, you'll see products that match your taste right on the homepage. We believe in making
            shopping personal, easy, and trustworthy.
          </p>
          <p
            className="text-md font-bold text-black underline cursor-pointer hover:text-gray-800 transition"
            onClick={() => navigate('/about-us')}
          >
            Know More
          </p>
        </div>
      </div>

      {/* Promo Image */}
      <div className="w-full lg:w-[280px] mx-auto mb-6">
        <img
          src={promoImg}
          alt="Promo"
          className="w-full h-110 object-cover shadow-md border border-gray-300"
        />
      </div>

      {/* Mini Product Cards with Navigation */}
      <div className="space-y-4 mb-6">
        {miniCards.map((item) => (
          <div
            key={item.id}
            className="flex items-center w-full lg:w-[280px] mx-auto border border-gray-300 bg-white cursor-pointer"
            onClick={() => navigate(`/product/${item.id}`)}
          >
            <img
              src={getMediaUrl(item.image)}
              alt={item.name}
              className="w-24 h-20 object-cover mr-3"
            />
            <div>
              <h3 className="text-lg font-semibold">{item.name}</h3>
              <p className="text-sm text-gray-600">{item.price}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Latest Post Card */}
      <div className="w-full lg:w-[280px] mx-auto border border-gray-300 bg-white shadow-md mb-6">
        <h2 className="text-xl font-bold px-4 pt-4">Latest Post</h2>
        <div className="p-2 pt-2">
          <div className="pb-3">
            <img
              src={getMediaUrl(latest_blog?.image)}
              alt="Latest Post"
              className="w-full h-48 object-cover rounded-md"
            />
          </div>
          <h3 className="text-lg font-semibold mb-1">
            {latest_blog?.title}
          </h3>
          <p className="text-sm text-gray-500 mb-2">{latest_blog?.created_at}</p>
          <p className="text-md text-gray-700 mb-3">
            {latest_blog?.content}
          </p>
        </div>
      </div>
    </div>
  );
};

export default LeftSidebar;
