import React, { useEffect, useState } from "react";
import arrivalImg from "../webassets/Brown-Modern-New-Arrival-Fashion-New-Arrival-Banner-1.jpg";
import Luxary from "../webassets/ttt-1.jpg";
import Evaluate from "../webassets/bgbr-1.jpg";
import Shop from "../Components/Shops";
import { useCart } from "../contexts/CartContext";
import { useHomepage } from "../contexts/HomepageContext";
import { Category } from "../services/types/product.types";
import { getMediaUrl } from "../helpers";
import { HomepageProduct } from "../services/types/homepage.types";
import { useNavigate } from "react-router-dom";
import { useSearchHistory } from "../contexts/SearchHistoryContext";
import { useAuth } from "../contexts/AuthContext";

const Home: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const { addToCart } = useCart();
  const { data } = useHomepage();
  const { recommendations, fetchRecommendations } = useSearchHistory();

  const [selectedCategory, setSelectedCategory] = useState<"men" | "women">(
    "men"
  );

  const essentials = (data?.categories || []) as Category[];
  const menArrivals = data?.latest_mens_products || [];
  const womenArrivals = data?.latest_womens_products || [];
  const currentArrivals =
    selectedCategory === "men" ? menArrivals : womenArrivals;

  const handleAddToCart = (item: HomepageProduct) => {
    addToCart({ quantity: 1, product_id: item.id });
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchRecommendations();
    }
  }, []);

  console.log("Recommendations:", recommendations);

  return (
    <div className="sm:px-8 md:px-12 py-10 text-center">
      {recommendations && recommendations.length > 0 && (
        <>
          <h1 className="text-3xl sm:text-4xl font-semibold mb-8">
            You might be interested In
          </h1>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-3 gap-y-5 sm:gap-x-5 sm:gap-y-8 max-w-5xl mx-auto mb-12">
            {recommendations.map((recommendation, index) => {
              return (
                <div key={index} className={`flex flex-col items-center ${""}`}>
                  <img
                    src={getMediaUrl(recommendation.product.image)}
                    alt={recommendation.product.name}
                    className="rounded-full w-28 h-28 sm:w-36 sm:h-36 md:w-44 md:h-44 object-cover shadow-lg transition-transform duration-300 hover:scale-105"
                  />
                  <p className="mt-3 text-lg font-medium">
                    {recommendation.product.name}
                  </p>
                </div>
              );
            })}
          </div>
        </>
      )}

      <h1 className="text-3xl sm:text-4xl font-semibold mb-8">
        Choose Your Essentials
      </h1>

      {/* Essentials Grid with Search History Highlight */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-3 gap-y-5 sm:gap-x-5 sm:gap-y-8 max-w-5xl mx-auto mb-12">
        {[...essentials].map((category, index) => {
          return (
            <div key={index} className={`flex flex-col items-center ${""}`}>
              <img
                src={getMediaUrl(category.image)}
                alt={category.name}
                className="rounded-full w-28 h-28 sm:w-36 sm:h-36 md:w-44 md:h-44 object-cover shadow-lg transition-transform duration-300 hover:scale-105"
              />
              <p className="mt-3 text-lg font-medium">{category.name}</p>
            </div>
          );
        })}
      </div>

      {/* New Arrival Banner */}
      <div className="max-w-3xl mx-auto mb-6">
        <img
          src={arrivalImg}
          alt="New Arrival"
          className="w-full h-auto rounded-lg shadow-xl"
        />
      </div>

      {/* New Arrivals Switch */}
      <h2 className="text-2xl sm:text-3xl font-semibold mb-2">New Arrivals</h2>
      <div className="flex justify-center items-center space-x-6 mb-6 text-gray-600 text-xl sm:text-2xl">
        <span
          onClick={() => setSelectedCategory("men")}
          className={`cursor-pointer hover:text-black transition ${
            selectedCategory === "men" ? "font-bold text-black" : ""
          }`}
        >
          For Men
        </span>
        <span
          onClick={() => setSelectedCategory("women")}
          className={`cursor-pointer hover:text-black transition ${
            selectedCategory === "women" ? "font-bold text-black" : ""
          }`}
        >
          For Women
        </span>
      </div>

      {/* New Arrivals Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-3xl mx-auto ">
        {currentArrivals.map((item, index) => (
          <div
            key={index}
            className="border border-gray-200 shadow-md overflow-hidden bg-white flex flex-col hover:shadow-xl transition duration-300"
          >
            <img
              src={getMediaUrl(item.image)}
              alt={item.name}
              className="w-full h-56 object-cover"
            />
            <div className="p-4 flex flex-col items-center text-center">
              <p className="text-lg font-semibold">{item.name}</p>
              <p className="text-gray-600 mt-1">${item.price}</p>
              <button
                className="mt-3 px-4 py-2 bg-black text-white text-sm rounded hover:bg-gray-800 transition"
                onClick={() => handleAddToCart(item)}
              >
                Add to Cart
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Shop New Arrival Button */}
      <div className="mb-4">
        <button
          className="bg-black text-white px-6 sm:px-12 py-2 sm:py-3 text-sm sm:text-xl mt-8 rounded hover:bg-gray-800 transition"
          onClick={() => navigate("/new-arrival")}
        >
          Shop New Arrival
        </button>
      </div>

      {/* Promotional Banners */}
      <div className="flex flex-col sm:flex-row justify-center items-center gap-4 mt-6 px-4">
        {/* Promo 1 */}
        <div className="relative w-full sm:w-1/2 max-w-sm rounded overflow-hidden shadow-lg">
          <img
            src={Luxary}
            alt="Promo Men"
            className="w-full sm:h-96 lg:h-[30rem] object-cover"
          />
          <div className="absolute inset-0 bg-black/40 flex flex-col justify-center sm:justify-between items-center text-black px-4 py-6">
            <h3 className="text-center text-base sm:text-xl lg:text-3xl font-semibold mt-6 sm:mt-20">
              Luxury Leather for <br /> Every Journey
            </h3>
            <button
              className="mt-4 sm:mt-6 bg-white text-black text-sm sm:text-lg px-5 sm:px-7 py-2 sm:py-3 rounded hover:bg-black hover:text-white transition"
              onClick={() => navigate("/shop")}
            >
              Shop Now
            </button>
          </div>
        </div>

        {/* Promo 2 */}
        <div className="relative w-full sm:w-1/2 max-w-sm rounded overflow-hidden shadow-lg">
          <img
            src={Evaluate}
            alt="Promo Women"
            className="w-full sm:h-96 lg:h-[30rem] object-cover"
          />
          <div className="absolute inset-0 bg-black/40 flex flex-col justify-center sm:justify-between items-center text-black px-4 py-6">
            <h3 className="text-center text-base sm:text-xl lg:text-3xl font-semibold mt-6 sm:mt-20">
              Elevate Your Style <br /> with Luxe Leather
            </h3>
            <button
              className="mt-4 sm:mt-6 bg-white text-black text-sm sm:text-lg px-5 sm:px-7 py-2 sm:py-3 rounded hover:bg-black hover:text-white transition"
              onClick={() => navigate("/shop")}
            >
              Shop Now
            </button>
          </div>
        </div>
      </div>

      {/* Shop Component */}
      <div className="mt-4">
        <Shop />
      </div>
    </div>
  );
};

export default Home;
