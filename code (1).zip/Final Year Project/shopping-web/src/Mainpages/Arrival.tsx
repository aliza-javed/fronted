import React, { useState, useEffect, } from 'react';
import { ShoppingCart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

import { FaArrowLeft, FaArrowRight } from "react-icons/fa";
import { useCart } from "../contexts/CartContext";
import { useProduct } from "../contexts/ProductContext";
import { useModifiers } from "../contexts/ModifiersContext";
import { ProductFilters, Product } from "../services/types/product.types";


const NewArrival: React.FC = () => {
  const { addToCart } = useCart();
  const {
    products,
    loading,
    error,
    fetchNewArrivals,
    totalProducts,
    nextPage,
    previousPage,
  } = useProduct();
  const {
    sizes,
    leatherTypes,
    colors,
  } = useModifiers();
  const navigate = useNavigate();

  const [filters, setFilters] = useState<ProductFilters>({
    page: 1,
    ordering: "default",
  });

  const [selectedSizes, setSelectedSizes] = useState<number[]>([]);
  const [selectedLeatherTypes, setSelectedLeatherTypes] = useState<number[]>(
    []
  );
  const [selectedColors, setSelectedColors] = useState<number[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [priceRange, setPriceRange] = useState<{
    min: number | null;
    max: number | null;
  }>({ min: null, max: null });

  useEffect(() => {
    fetchNewArrivals(filters);
  }, [filters, fetchNewArrivals]);

  // Calculate min and max price from products
  useEffect(() => {
    if (products.length > 0) {
      const prices = products.map((p) => parseFloat(p.price.replace("$", "")));
      const min = 0;
      const max = Math.max(...prices) + 100;
      setPriceRange({ min, max });
    }
  }, [products]);

  const handlePriceChange = (newPrice: number) => {
    setFilters((prev) => ({
      ...prev,
      max_price: newPrice,
      ordering: newPrice > (prev.max_price || 0) ? "-price" : "price",
    }));
  };

  const handleSortChange = (sortType: string) => {
    setFilters((prev) => ({ ...prev, ordering: sortType, page: 1 }));
  };

  const handlePageChange = (page: number) => {
    setFilters((prev) => ({ ...prev, page }));
  };

  const handleAddToCart = async (product: Product) => {
    try {
      await addToCart({
        product_id: product.id,
        quantity: 1,
      });
    } catch (error) {
      console.error("Failed to add to cart:", error);
    }
  };

  const totalPages = Math.ceil((totalProducts || 0) / 16);

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-screen text-red-500">
        {error}
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 lg:p-16 bg-gray-50">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Sidebar Filters */}
        <div className="w-full lg:w-1/5 space-y-8">
          {/* Price Filter */}
          {priceRange.min !== null && priceRange.max !== null && (
            <div>
              <h3 className="text-2xl font-semibold mb-6">By Price</h3>
              <input
                type="range"
                min={priceRange.min}
                max={priceRange.max}
                value={filters.max_price || priceRange.max}
                onChange={(e) => handlePriceChange(Number(e.target.value))}
                className="w-full accent-black"
              />
              <div className="flex justify-between text-sm mt-4">
                <div className="text-center">
                  <div className="border px-4 py-3 text-gray-700 font-medium">
                    ${priceRange.min}
                  </div>
                  <span className="text-md text-gray-600 mt-1 block">
                    Min. Price
                  </span>
                </div>
                <div className="text-center">
                  <div className="border px-4 py-3 text-gray-700 font-medium">
                    ${filters.max_price || priceRange.max}
                  </div>
                  <span className="text-md text-gray-600 mt-1 block">
                    Max. Price
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Size Filter */}
          <div>
            <h3 className="text-2xl font-semibold mb-6">By Size</h3>
            {sizes.map((size) => (
              <div
                key={size.id}
                className="flex items-center space-x-2 lg:text-lg mb-4"
              >
                <input
                  type="checkbox"
                  className="accent-black w-5 h-5"
                  checked={selectedSizes.includes(size.id)}
                  onChange={() => {
                    const newSizes = selectedSizes.includes(size.id)
                      ? selectedSizes.filter((s) => s !== size.id)
                      : [...selectedSizes, size.id];
                    setSelectedSizes(newSizes);
                    setFilters((prev) => ({ ...prev, size: newSizes[0] }));
                  }}
                />
                <span className="ml-2 text-gray-700">{size.name}</span>
              </div>
            ))}
          </div>

          {/* Leather Filter */}
          <div>
            <h3 className="text-2xl font-semibold mb-6">By Leather Type</h3>
            {leatherTypes.map((leather) => (
              <div
                key={leather.id}
                className="flex items-center space-x-2 lg:text-lg mb-4"
              >
                <input
                  type="checkbox"
                  className="accent-black w-5 h-5"
                  checked={selectedLeatherTypes.includes(leather.id)}
                  onChange={() => {
                    const newTypes = selectedLeatherTypes.includes(leather.id)
                      ? selectedLeatherTypes.filter((t) => t !== leather.id)
                      : [...selectedLeatherTypes, leather.id];
                    setSelectedLeatherTypes(newTypes);
                    setFilters((prev) => ({ ...prev, leather: newTypes[0] }));
                  }}
                />
                <span className="ml-2 text-gray-700">{leather.name}</span>
              </div>
            ))}
          </div>

          {/* Color Filter */}
          <div>
            <h3 className="text-2xl font-semibold mb-6">By Color</h3>
            {colors.map((color) => (
              <div
                key={color.id}
                className="flex items-center space-x-2 lg:text-lg mb-4"
              >
                <input
                  type="checkbox"
                  className="accent-black w-5 h-5"
                  checked={selectedColors.includes(color.id)}
                  onChange={() => {
                    const newColors = selectedColors.includes(color.id)
                      ? selectedColors.filter((c) => c !== color.id)
                      : [...selectedColors, color.id];
                    setSelectedColors(newColors);
                    setFilters((prev) => ({ ...prev, color: newColors[0] }));
                  }}
                />
                <span className="ml-2 text-gray-700">{color.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="w-full lg:w-4/5 lg:ml-16">
          <div className="flex justify-between items-center mb-6">
            <p className="text-gray-700 font-medium">
              Showing {products.length} of {totalProducts} results
            </p>
            <div className="flex items-center gap-2">
              <span className="text-gray-700 font-medium">Sort by:</span>
              <select
                className="border px-3 py-2 rounded-md text-gray-700 text-sm"
                value={filters.ordering || "default"}
                onChange={(e) => handleSortChange(e.target.value)}
              >
                <option value="default">Default Sorting</option>
                <option value="-id">Sort by Popularity</option>
                <option value="-created_at">Sort by Latest</option>
                <option value="price">Price: Low to High</option>
                <option value="-price">Price: High to Low</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center items-center min-h-[400px]">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-black"></div>
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-12">
              <h3 className="text-2xl font-semibold text-gray-700 mb-2">
                No Products Found
              </h3>
              <p className="text-gray-500">
                Try adjusting your filters to find what you're looking for.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="relative group overflow-hidden"
                >
                  <div className="relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      onClick={() => navigate(`/product/${product.id}`)}
                      className="w-full h-72 object-cover transition-transform duration-300 group-hover:scale-105 cursor-pointer"
                    />
                    <button
                      className="absolute bottom-0 left-0 w-full bg-black text-white text-sm py-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      onClick={() => setSelectedProduct(product)}
                    >
                      Quick View
                    </button>
                  </div>
                  <div className="flex justify-between items-center mt-4">
                    <div>
                      <p className="text-gray-800 font-semibold text-lg">
                        {product.name}
                      </p>
                      <p className="text-gray-600 text-md">{product.price}</p>
                    </div>
                    <button
                      className="bg-black text-white p-3"
                      onClick={() => handleAddToCart(product)}
                    >
                      <ShoppingCart size={18} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-4 mt-10">
              <button
                disabled={!previousPage}
                onClick={() => handlePageChange((filters.page || 1) - 1)}
              >
                <FaArrowLeft
                  className={`text-lg ${!previousPage ? "text-gray-300" : "text-black"
                    }`}
                />
              </button>
              {[...Array(totalPages)].map((_, i) => (
                <button
                  key={i}
                  className={`px-3 py-1 rounded ${filters.page === i + 1
                    ? "bg-black text-white"
                    : "bg-gray-200 text-gray-800"
                    }`}
                  onClick={() => handlePageChange(i + 1)}
                >
                  {i + 1}
                </button>
              ))}
              <button
                disabled={!nextPage}
                onClick={() => handlePageChange((filters.page || 1) + 1)}
              >
                <FaArrowRight
                  className={`text-lg ${!nextPage ? "text-gray-300" : "text-black"
                    }`}
                />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Quick View Popup */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-md max-w-4xl w-full flex flex-col md:flex-row relative">
            <button
              className="absolute top-4 right-4 bg-black text-white rounded-full w-7 h-7 flex items-center justify-center hover:scale-105 transition"
              onClick={() => setSelectedProduct(null)}
            >
              &times;
            </button>
            <img
              src={selectedProduct.image}
              alt={selectedProduct.name}
              className="w-full md:w-1/2 h-auto object-cover rounded"
            />
            <div className="p-4 md:p-6 flex-1">
              <h2 className="text-2xl font-semibold mb-2">
                {selectedProduct.name}
              </h2>
              <p className="text-xl text-gray-700 mb-4">
                {selectedProduct.price}
              </p>
              <p className="text-gray-600 mb-4">
                {selectedProduct.description}
              </p>
              <div>
                <h4 className="text-md font-semibold mb-2">Size</h4>
                <div className="grid grid-cols-3 gap-2">
                  {sizes.map((size) => (
                    <button
                      key={size.id}
                      className="border px-3 py-1 rounded hover:bg-black hover:text-white transition col-span-1"
                    >
                      {size.name}
                    </button>
                  ))}
                </div>
              </div>
              <button
                className="mt-6 text-sm text-red-500 underline md:hidden"
                onClick={() => setSelectedProduct(null)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NewArrival;
