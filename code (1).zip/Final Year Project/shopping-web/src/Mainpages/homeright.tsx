import React from 'react';
import { useNavigate } from 'react-router-dom';
import rightSidebarImg from '../webassets/Grey-Summer-sale-Monochrome-leather-bag-Instagram-Story-2.jpg';
import mariaImg from '../webassets/image-6.png';
import { useCart } from '../contexts/CartContext';
import { useHomepage } from '../contexts/HomepageContext';
import { HomepageProduct } from '../services/types/homepage.types';
import { getMediaUrl } from '../helpers';

const RightSidebar: React.FC = () => {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { data } = useHomepage()

  const productItems = [data?.most_sold_item || {} as HomepageProduct]

  const handleAddToCart = (item: HomepageProduct) => {
    addToCart({ product_id: item.id, quantity: 1 });
  };

  const miniCards = data?.latest_products || [] as HomepageProduct[]

  return (
    <div className="w-full lg:w-1/5 px-2 mt-14 lg:mt-14">
      {/* Promo Image */}
      <div className="w-full lg:w-[280px] mx-auto mb-6">
        <img
          src={rightSidebarImg}
          alt="Sale Image"
          className="w-full h-100 object-cover shadow-md border border-gray-300"
        />
      </div>

      {/* Leather Bag Card */}
      {productItems.map((item, index) => (
        <div key={index} className="w-full lg:w-[280px] mx-auto mb-6 mt-12">
          <div className="border border-gray-200 shadow-md overflow-hidden bg-white flex flex-col hover:shadow-xl transition duration-300">
            <img
              src={getMediaUrl(item?.image)}
              alt={item?.name}
              className="w-full h-64 object-cover"
              onClick={() => navigate(`/product/${item.id}`)}
            />
            <div className="p-4 flex flex-col items-center text-center">
              <p className="text-xl font-semibold">{item?.name}</p>
              <p className="text-gray-600 mt-1 text-lg">{item.price}</p>
              <button
                className="mt-3 px-5 py-3 bg-black text-white text-sm rounded hover:bg-gray-800 transition"
                onClick={() => handleAddToCart(item)}
              >
                Add to Cart
              </button>
            </div>
          </div>
        </div>
      ))}

      {/* Mini Product Cards */}
      <div className="space-y-4 mb-6">
        {miniCards.map((item, index) => {
          const isSplitPrice = index === 0 || index === 3;
          const prices = item.price.split(' ');
          const originalPrice = prices[1] || prices[0];
          const discountedPrice = prices[0];

          return (
            <div
              key={index}
              className="flex items-center w-full lg:w-[280px] mx-auto border border-gray-300 bg-white cursor-pointer mt-4"
              onClick={() => navigate(`/product/${item.id}`)}
            >
              <img
                src={getMediaUrl(item.image)}
                alt={item.name}
                className="w-24 h-20 object-cover mr-3"
              />
              <div>
                <h3 className="text-lg font-semibold">{item.name}</h3>
                <div className="flex items-center">
                  {isSplitPrice ? (
                    <>
                      <p className="text-sm text-gray-600 line-through mr-2">{originalPrice}</p>
                      <p className="text-sm text-gray-800">{discountedPrice}</p>
                    </>
                  ) : (
                    <p className="text-sm text-gray-800">{item.price}</p>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Testimonial Card */}
      <div className="w-full lg:w-[280px] mx-auto border border-gray-300 shadow-md bg-white p-3 mt-12">
        <div className="p-3">
          <p className="text-lg text-gray-600 mb-4">
            Aliza strives to combine technical precision with creative vision. Her journey is rooted in her dedication to building meaningful,
            user-centered solutions that push boundaries and foster growth, both in tech and in business.
          </p>
          <div className="w-28 h-28 mx-auto rounded-full overflow-hidden mb-2">
            <img
              src={mariaImg}
              alt="Aliza"
              className="w-full h-full object-cover"
            />
          </div>
          <p className="text-center text-2xl font-semibold">Aliza</p>
        </div>
      </div>
    </div>
  );
};

export default RightSidebar;
