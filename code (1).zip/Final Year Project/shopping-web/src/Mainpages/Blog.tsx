import React from 'react';
import { FaUser, FaRegCalendarAlt } from 'react-icons/fa';
import { FaMessage } from 'react-icons/fa6';
import { useBlog } from '../contexts/BlogContext';
import { getMediaUrl } from '../helpers';

const Blog: React.FC = () => {
  const { blogs } = useBlog()


  return (
    <div className="p-4 sm:p-8 md:p-16 bg-gray-50">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {blogs.map(blog => (
          <div className="w-full">
            <img src={getMediaUrl(blog.image)} alt="Sustainable Leather" className="w-full h-auto rounded-md mb-4 max-w-full" />
            <h3 className="text-xl text-black mb-2">{blog.title}</h3>
            <h4 className="text-2xl font-semibold text-black mb-1">{blog.subtitle}</h4>

            <div className="flex flex-wrap items-center justify-between text-gray-500 text-xl mb-4 gap-2">
              <div className="flex items-center space-x-4">
                <div className="flex items-center">
                  <FaUser className="mr-1" />
                  <span>{blog.author}</span>
                </div>
                <div className="flex items-center">
                  <FaRegCalendarAlt className="mr-1" />
                  <span>{blog.created_at}</span>
                </div>
              </div>
              <div className="relative">
                <FaMessage className="text-black text-xl" />
                <div className="absolute -top-2 -right-2 bg-black text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                  {blog.comment_count}
                </div>
              </div>
            </div>

            <p className=" lg:text-lg text-base sm:text-lg md:text-xl text-gray-700 mb-4">
              {blog.content}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Blog;
