import axiosInstance from '../config/axios';
import { HomepageData } from './types/homepage.types';

class HomepageService {
  private static instance: HomepageService;

  private constructor() { }

  public static getInstance(): HomepageService {
    if (!HomepageService.instance) {
      HomepageService.instance = new HomepageService();
    }
    return HomepageService.instance;
  }

  async getHomepageData(): Promise<HomepageData> {
    const response = await axiosInstance.get<HomepageData>('/');
    return response.data;
  }
}

export { HomepageService }; 