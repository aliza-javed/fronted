import { api } from "../config/api";
import { Recommendation } from "../contexts/SearchHistoryContext";
import {
  SearchHistoryResponse,
  SearchHistoryRequest,
  DeleteSearchHistoryRequest,
} from "./types/search-history.types";

export const searchHistoryService = {
  getSearchHistory: async (): Promise<SearchHistoryResponse> => {
    const response = await api.get("/search-history/");
    return response.data;
  },

  addSearchHistory: async (data: SearchHistoryRequest): Promise<void> => {
    await api.post("/search-history/", data);
  },

  deleteSearchHistory: async (
    data: DeleteSearchHistoryRequest
  ): Promise<void> => {
    await api.delete(`/search-history/${data.id}/`);
  },

  clearSearchHistory: async (): Promise<void> => {
    await api.delete("/search-history/clear/");
  },
  getRecommendations: async (): Promise<Recommendation[]> => {
    const response = await api.get(`/recommendations/`);
    return response.data;
  },
  postRecommendations: async (data: { product_id: number }): Promise<void> => {
    await api.post(`/recommendations/`, data);
  },
};
