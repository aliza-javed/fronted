export interface ContactUsRequest {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export interface ContactUsResponse {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  created_at: string;
  status: 'pending' | 'in_progress' | 'resolved';
} 