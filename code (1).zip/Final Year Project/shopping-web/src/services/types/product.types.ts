export interface Category {
  id: number;
  name: string;
  image: string;
}

export interface Size {
  id: number;
  name: string;
}

export interface Color {
  id: number;
  name: string;
}

export interface Leather {
  id: number;
  name: string;
}

export interface RecommendedProduct {
  id: number;
  name: string;
  price: string;
  image: string;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: string;
  image: string;
  category: Category;
  stock: number;
  size: Size;
  color: Color;
  leather: Leather;
  for_gender: 'male' | 'female' | null;
  created_at: string;
  recommended_products: RecommendedProduct[];
}

export interface ProductListResponse {
  count: number;
  next: string | null;
  previous: string | null;
  results: Product[];
}

export interface ProductFilters {
  search?: string;
  category?: number;
  size?: number;
  color?: number;
  leather?: number;
  min_price?: number;
  max_price?: number;
  for_gender?: 'male' | 'female';
  ordering?: string;
  page?: number;
} 