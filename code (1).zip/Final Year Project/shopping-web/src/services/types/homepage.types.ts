import { Category } from './product.types';

export interface HomepageProduct {
  id: number;
  name: string;
  price: string;
  image: string;
  category: Category;
}

export interface HomepageBlog {
  id: number;
  title: string;
  subtitle: string;
  content: string;
  image: string;
  author: string;
  created_at: string;
  comment_count: number;
}

export interface HomepageData {
  categories: Category[];
  latest_mens_products: HomepageProduct[];
  latest_womens_products: HomepageProduct[];
  latest_blog: HomepageBlog | null;
  oldest_products: HomepageProduct[];
  latest_products: HomepageProduct[];
  random_products: HomepageProduct[];
  most_sold_item: HomepageProduct;
} 