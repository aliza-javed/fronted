export interface OrderItem {
  id: number;
  product: {
    id: number;
    name: string;
    image: string;
    price: string;
  };
  quantity: number;
  price_at_time: string;
  total_price: string;
}

export interface Order {
  id: number;
  order_number: string;
  created_at: string;
  updated_at: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  shipping_address: string;
  shipping_city: string;
  shipping_state: string;
  shipping_country: string;
  shipping_zip_code: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  status_display: string;
  payment_status: 'pending' | 'paid' | 'failed' | 'refunded';
  payment_status_display: string;
  payment_method: 'credit_card' | 'debit_card' | 'paypal' | 'bank_transfer';
  payment_method_display: string;
  total_price: string;
  shipping_cost: string;
  tax: string;
  discount: string;
  final_price: string;
  notes: string | null;
  tracking_number: string | null;
  estimated_delivery: string | null;
  items: OrderItem[];
}

export interface CreateOrderRequest {
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  shipping_address: string;
  shipping_city: string;
  shipping_state: string;
  shipping_country: string;
  shipping_zip_code: string;
  payment_method: 'credit_card' | 'debit_card' | 'paypal' | 'bank_transfer';
  notes?: string;
}

export interface UpdateOrderStatusRequest {
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
} 