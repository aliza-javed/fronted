export interface Blog {
  id: number;
  title: string;
  subtitle: string;
  content: string;
  image: string;
  author: string;
  created_at: string;
  comment_count: number;
}

export interface BlogListResponse extends Array<Blog> {} 