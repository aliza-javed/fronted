export interface SearchHistoryItem {
  id: number;
  query: string;
  created_at: string;
  user_id: number;
}

export interface SearchHistoryResponse {
  count: number;
  next: string | null;
  previous: string | null;
  results: SearchHistoryItem[];
}

export interface SearchHistoryRequest {
  query: string;
}

export interface DeleteSearchHistoryRequest {
  id: number;
} 