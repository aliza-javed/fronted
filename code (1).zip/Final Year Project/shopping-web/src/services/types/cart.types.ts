export interface CartProduct {
  id: number;
  name: string;
  image: string;
  price: number;
}

export interface CartItem {
  id: number;
  product: CartProduct;
  quantity: number;
  price_at_time: number;
  total_price: number;
  image: string;
  name: string;
}

export interface Cart {
  id: number;
  items: CartItem[];
  total_items: number;
  total_price: number;
}

export interface AddToCartRequest {
  product_id: number;
  quantity: number;
}

export interface UpdateCartItemRequest {
  quantity: number;
} 