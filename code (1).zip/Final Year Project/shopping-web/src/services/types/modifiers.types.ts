export interface Size {
  id: number;
  name: string;
}

export interface Leather {
  id: number;
  name: string;
}

export interface Color {
  id: number;
  name: string;
}

export interface ModifiersResponse {
  sizes: Size[];
  leather_types: Leather[];
  colors: Color[];
} 