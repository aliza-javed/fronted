import axiosInstance from '../config/axios';
import { Order, CreateOrderRequest, UpdateOrderStatusRequest } from './types/order.types';

export class OrderService {
  private static instance: OrderService;

  private constructor() { }

  public static getInstance(): OrderService {
    if (!OrderService.instance) {
      OrderService.instance = new OrderService();
    }
    return OrderService.instance;
  }

  async getAllOrders(): Promise<{ results: Order[] }> {
    const response = await axiosInstance.get<{ results: Order[] }>('/orders/');
    return response.data;
  }

  async getOrderById(id: number): Promise<Order> {
    const response = await axiosInstance.get<Order>(`/orders/${id}/`);
    return response.data;
  }

  async createOrder(data: CreateOrderRequest): Promise<Order> {
    const response = await axiosInstance.post<Order>('/orders/', data);
    return response.data;
  }

  async updateOrderStatus(id: number, data: UpdateOrderStatusRequest): Promise<Order> {
    const response = await axiosInstance.patch<Order>(`/orders/${id}/status/`, data);
    return response.data;
  }
} 