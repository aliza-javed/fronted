import { api } from "../config/api";
import { ModifiersResponse } from "./types/modifiers.types";

export const modifiersService = {
  getModifiers: async (): Promise<ModifiersResponse> => {
    const response = await api.get("/modifiers/");
    return response.data;
  },
};
