import axiosInstance from '../config/axios';
import { Category } from './types/product.types';

export class CategoryService {
  private static instance: CategoryService;

  private constructor() { }

  public static getInstance(): CategoryService {
    if (!CategoryService.instance) {
      CategoryService.instance = new CategoryService();
    }
    return CategoryService.instance;
  }

  async getAllCategories(): Promise<Category[]> {
    const response = await axiosInstance.get<Category[]>('/categories/');
    return response.data;
  }
} 