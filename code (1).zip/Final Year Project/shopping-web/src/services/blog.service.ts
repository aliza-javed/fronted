import axiosInstance from '../config/axios';
import { Blog, BlogListResponse } from './types/blog.types';

export class BlogService {
  private static instance: BlogService;

  private constructor() { }

  public static getInstance(): BlogService {
    if (!BlogService.instance) {
      BlogService.instance = new BlogService();
    }
    return BlogService.instance;
  }

  async getAllBlogs(): Promise<BlogListResponse> {
    const response = await axiosInstance.get<BlogListResponse>('/blogs/');
    return response.data;
  }

  async getBlogById(id: number): Promise<Blog> {
    const response = await axiosInstance.get<Blog>(`/blogs/${id}/`);
    return response.data;
  }
} 