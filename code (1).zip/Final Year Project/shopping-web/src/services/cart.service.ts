import axiosInstance from '../config/axios';
import { Cart, AddToCartRequest, UpdateCartItemRequest } from './types/cart.types';

export class CartService {
  private static instance: CartService;

  private constructor() { }

  public static getInstance(): CartService {
    if (!CartService.instance) {
      CartService.instance = new CartService();
    }
    return CartService.instance;
  }

  async getCart(): Promise<Cart> {
    const response = await axiosInstance.get<Cart>('/cart/');
    return response.data;
  }

  async addToCart(data: AddToCartRequest): Promise<Cart> {
    const response = await axiosInstance.post<Cart>('/cart/', data);
    return response.data;
  }

  async updateCartItem(id: number, data: UpdateCartItemRequest): Promise<Cart> {
    const response = await axiosInstance.patch<Cart>(`/cart/items/${id}/`, data);
    return response.data;
  }

  async increaseCartItemQuantity(id: number): Promise<Cart> {
    const response = await axiosInstance.post<Cart>(`/cart/items/${id}/increase/`);
    return response.data;
  }

  async decreaseCartItemQuantity(id: number): Promise<Cart> {
    const response = await axiosInstance.post<Cart>(`/cart/items/${id}/decrease/`);
    return response.data;
  }

  async removeCartItem(id: number): Promise<Cart> {
    const response = await axiosInstance.delete<Cart>(`/cart/items/${id}/`);
    return response.data;
  }
} 