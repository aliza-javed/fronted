import axiosInstance from '../config/axios';
import { User, LoginRequest, RegisterRequest } from './types/auth.types';

export default class AuthService {
  private static instance: AuthService;

  private constructor() { }

  public static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  async login(data: LoginRequest): Promise<{ user: User; token: string }> {
    const response = await axiosInstance.post<{ user: User; token: string }>('/auth/login/', data);
    return response.data;
  }

  async register(data: RegisterRequest): Promise<{ user: User; token: string }> {
    const response = await axiosInstance.post<{ user: User; token: string }>('/auth/register/', data);
    return response.data;
  }

  async logout(): Promise<void> {
    await axiosInstance.post('/auth/logout');
  }

  async getProfile(): Promise<User> {
    const response = await axiosInstance.get<User>('/auth/profile/');
    return response.data;
  }
}

