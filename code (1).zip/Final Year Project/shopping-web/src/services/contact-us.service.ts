import { api } from '../config/api';
import { ContactUsRequest, ContactUsResponse } from './types/contact-us.types';

export const contactUsService = {
  submitContactForm: async (data: ContactUsRequest): Promise<ContactUsResponse> => {
    const response = await api.post('/contact/submit/', data);
    return response.data;
  },

  getContactStatus: async (id: number): Promise<ContactUsResponse> => {
    const response = await api.get(`/contact-us/${id}/`);
    return response.data;
  }
}; 