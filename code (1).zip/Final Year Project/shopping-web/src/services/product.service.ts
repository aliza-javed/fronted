import axiosInstance from '../config/axios';
import { Product, ProductListResponse, ProductFilters } from './types/product.types';

export class ProductService {
  private static instance: ProductService;

  private constructor() { }

  public static getInstance(): ProductService {
    if (!ProductService.instance) {
      ProductService.instance = new ProductService();
    }
    return ProductService.instance;
  }

  async getProducts(filters?: ProductFilters): Promise<ProductListResponse> {
    const response = await axiosInstance.get<ProductListResponse>('/products/', { params: filters });
    return response.data;
  }

  async getProductById(id: number): Promise<Product> {
    const response = await axiosInstance.get<Product>(`/products/${id}/`);
    return response.data;
  }

  async getNewArrivals(filters?: ProductFilters): Promise<ProductListResponse> {
    const response = await axiosInstance.get<ProductListResponse>('/products/new-arrivals/', { params: filters });
    return response.data;
  }
} 