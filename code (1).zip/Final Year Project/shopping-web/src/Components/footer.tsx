import React from 'react';
import {
  FaFacebookF,
  FaInstagram,
  FaPinterestP,
  FaTwitter,
  FaLinkedinIn,
  FaTiktok,
  FaYoutube
} from 'react-icons/fa';
import contactImage from '../webassets/image-removebg-preview-4neww.png';

const Footer: React.FC = () => {

  if (["login", "signup"].some(path => window.location.href.includes(path))) {
    return
  }
  return (
    <>
      <footer className="flex flex-col md:flex-row flex-wrap justify-between bg-[#3b2322] text-white py-8 px-4 md:px-8">
        {/* About Us */}
        <div className="w-full md:w-1/2 lg:w-1/4 mt-8">
          <h3 className="text-2xl font-semibold mb-4">About Us</h3>
          <p className="text-base">
            Aliza Javed and Muhammad Asim, the founders of the brand, combine technology, design, and business expertise.
            Aliza drives innovation, while Asim focuses on strategic growth.
            Together, they create high-quality leather products with timeless craftsmanship.
          </p>
        </div>

        {/* Quick Links */}
        <div className="w-full md:w-1/2 lg:w-1/4 mt-10">
          <h3 className="text-2xl font-semibold mb-4">Quick Links</h3>
          {["Offer Zone", "SiteMap", "New Launch", "Login", "Career"].map((link, i) => (
            <a key={i} href="#" className="block mb-1 text-base hover:underline">{link}</a>
          ))}
        </div>

        {/* Help */}
        <div className="w-full md:w-1/2 lg:w-1/4 mt-10">
          <h3 className="text-2xl font-semibold mb-4">Help</h3>
          {["Return/Exchange", "Contact Us", "Shipping & Delivery", "Lost Password", "Privacy Policy"].map((link, i) => (
            <a key={i} href="#" className="block mb-1 text-base hover:underline">{link}</a>
          ))}
        </div>

        {/* Contact Details */}
        <div className="w-full md:w-1/2 lg:w-1/4 mt-10">
          <h3 className="text-2xl font-semibold mb-4">Contact Details</h3>
          <p className="text-base">Address: Bahawalpur</p>
          <p className="text-base">Contact: 304-5769012</p>
          <p className="text-base">E-mail: alizajaved783@gmail.com</p>
          <img
            src={contactImage}
            alt="Contact"
            className="mt-4 w-full max-w-xs rounded-md shadow-lg"
          />
        </div>
      </footer>

      {/* Bottom Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between bg-[#3b2322] text-white border-t border-gray-600 px-4 py-4 text-sm md:text-base">
        <p className="text-center md:text-left text-md mb-2 md:mb-0">
          © The Shop Mania | Developed by ThemeHunk
        </p>
        <div className="flex space-x-4 text-xl">
          <a href="#" aria-label="Facebook" className="text-[#1877f2] hover:text-[#1568C0]"><FaFacebookF /></a>
          <a href="#" aria-label="Instagram" className="text-[#e4405f] hover:text-[#C13584]"><FaInstagram /></a>
          <a href="#" aria-label="Pinterest" className="text-[#e60023] hover:text-[#BF0022]"><FaPinterestP /></a>
          <a href="#" aria-label="Twitter" className="text-[#1da1f2] hover:text-[#0d95e8]"><FaTwitter /></a>
          <a href="#" aria-label="LinkedIn" className="text-[#0077b5] hover:text-[#005d93]"><FaLinkedinIn /></a>
          <a href="#" aria-label="TikTok" className="text-black hover:text-[#69C9D0]"><FaTiktok /></a>
          <a href="#" aria-label="YouTube" className="text-[#ff0000] hover:text-[#e60000]"><FaYoutube /></a>
        </div>
      </div>
    </>
  );
};

export default Footer;
