import React, { useState } from 'react';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useNavigate } from 'react-router-dom';
import { useProduct } from '../contexts/ProductContext';
import { Product } from '../services/types/product.types';
import { getMediaUrl } from '../helpers';


const Shop: React.FC = () => {
    const { addToCart } = useCart();
    const { products } = useProduct()
    const navigate = useNavigate();
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

    const extendedProducts = products
    return (
        <div className=" ">
            <div className="flex flex-col gap-8">
                {/* Product Grid */}
                <div className="w-full lg:w-[730px] mx-auto">
                    <div className="flex justify-between items-center mb-6">
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 ">
                        {extendedProducts.map((product) => (
                            <div key={product.id} className="relative group overflow-hidden border border-gray-200 p-2  hover:shadow-xl transition-shadow duration-300">
                                <div className="relative">
                                    <img
                                        src={getMediaUrl(product.image)}
                                        alt={product.name}
                                        onClick={() => navigate(`/product/${product.id}`)}
                                        className="w-full h-52 object-cover transition-transform duration-300 group-hover:scale-105 cursor-pointer"
                                    />
                                    <button
                                        className="absolute bottom-0 left-0 w-full bg-black text-white text-sm py-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                                        onClick={() => setSelectedProduct(product)}
                                    >
                                        Quick View
                                    </button>
                                </div>
                                <div className="flex justify-between items-center mt-4">
                                    <div>
                                        <p className="text-gray-800 font-semibold text-lg">{product.name}</p>
                                        <p className="text-gray-600 text-md">{product.price}</p>
                                    </div>
                                    <button
                                        className="bg-black text-white p-3 rounded-full"
                                        onClick={() =>
                                            addToCart({ product_id: product.id, quantity: 1 })
                                        }
                                    >
                                        <ShoppingCart size={18} />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Quick View Popup */}
            {selectedProduct && (
                <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50">
                    <div className="bg-white rounded-md max-w-4xl w-full flex flex-col md:flex-row relative">
                        <button
                            className="absolute top-4 right-4 bg-black text-white rounded-full w-7 h-7 flex items-center justify-center hover:scale-105 transition"
                            onClick={() => setSelectedProduct(null)}
                        >
                            &times;
                        </button>
                        <img
                            src={getMediaUrl(selectedProduct.image)}
                            alt={selectedProduct.name}
                            className="w-full md:w-1/2 h-auto object-cover rounded"
                        />
                        <div className="p-4 md:p-6 flex-1 ">
                            <h2 className="text-2xl font-semibold mb-2">{selectedProduct.name}</h2>
                            <p className="text-xl text-gray-700 mb-4">{selectedProduct.price}</p>
                            <p className="text-gray-600 mb-4">
                                Malesuada erat dapibus eu auctor cras quisque bibendum enim urna nec aliquam est sociis,
                                condimentum cubilia integer et feugiat porttitor euismod nibh dictum arcu quam.
                            </p>
                            <div>
                                <h4 className="text-md font-semibold mb-2">Size</h4>
                                <div className="grid grid-cols-3 gap-2">
                                    {['Extra Large', 'Large', 'Medium', 'Small'].map((size) => (
                                        <button
                                            key={size}
                                            className="border px-3 py-1 rounded hover:bg-black hover:text-white transition col-span-1"
                                        >
                                            {size}
                                        </button>
                                    ))}
                                </div>
                            </div>
                            <button
                                className="mt-6 text-sm text-red-500 underline md:hidden"
                                onClick={() => setSelectedProduct(null)}
                            >
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Shop;
