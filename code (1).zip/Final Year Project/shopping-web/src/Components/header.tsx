// /src/components/header.tsx:

import { useState, useRef, useEffect } from "react";
import {
  FaSearch,
  FaUser,
  FaShoppingBag,
  FaPhone,
  FaBars,
  FaTimes,
} from "react-icons/fa";
import logo from "../webassets/5.png";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useCart } from "../contexts/CartContext";
import { useAuth } from "../contexts/AuthContext";
import Cart from "./Cart";
import { useProduct } from "../contexts/ProductContext";
import { Product } from "../services/types/product.types";
import { useSearchHistory } from "../contexts/SearchHistoryContext";

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  const [isSearchVisible, setSearchVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Product[]>([]);

  const location = useLocation();
  const { cart } = useCart();
  const { fetchProducts } = useProduct();
  const { addRecommendations } = useSearchHistory();
  const { token, logout } = useAuth();
  const totalQuantity = cart?.items.length || 0;
  const navigate = useNavigate();

  const handleMenuToggle = () => setIsMenuOpen(!isMenuOpen);
  const handleCartToggle = () => setIsCartOpen(!isCartOpen);
  const handleLogout = () => {
    logout();
    window.location.href = "/";
  };

  const handleOrdersClick = () => {
    navigate("/orders");
  };

  // Handle clicks outside the profile dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        profileRef.current &&
        !profileRef.current.contains(event.target as Node)
      ) {
        setIsProfileOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const navItems = [
    { name: "Home", path: "/" },
    { name: "Shop", path: "/shop" },
    { name: "New Arrival", path: "/new-arrival" },
    { name: "Blog", path: "/blog" },
    { name: "Contact Us", path: "/contact-us" },
    { name: "About Us", path: "/about-us" },
  ];

  if (["login", "signup"].some((path) => window.location.href.includes(path))) {
    return null;
  }

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.length > 2) {
      try {
        const response = await fetchProducts({ search: query });
        setSearchResults(response);
      } catch (error) {
        console.error("Search error:", error);
      }
    } else {
      setSearchResults([]);
    }
  };

  return (
    <header className="bg-[#3b2322] text-white">
      {/* Top Header */}
      <div className="flex items-center justify-between px-4 md:p-6 lg:p-8 sm:px-8 py-3 border-b border-gray-600 relative">
        <div className="hidden sm:flex items-center text-base font-medium">
          <FaPhone className="mr-2 text-xl" />
          Call To +1800090098
        </div>

        {/* Mobile Logo */}
        <div className="sm:hidden">
          <img src={logo} alt="Logo" className="h-10 object-contain" />
        </div>

        {/* Center Logo */}
        <div className="hidden sm:block absolute left-1/2 transform -translate-x-1/2">
          <img src={logo} alt="Logo" className="h-16 object-contain" />
        </div>

        <div className="flex items-center space-x-4 text-2xl">
          {/* Mobile Menu */}
          <div className="sm:hidden cursor-pointer" onClick={handleMenuToggle}>
            {isMenuOpen ? <FaTimes /> : <FaBars />}
          </div>

          {/* Search Icon */}
          <div className="hidden sm:block relative">
            <FaSearch
              className="cursor-pointer"
              onClick={() => setSearchVisible(!isSearchVisible)}
            />
            {isSearchVisible && (
              <div className="absolute top-full right-0 mt-2 w-[250px] bg-[#2b1c1b] border border-gray-500 rounded-md shadow-lg p-2 z-50">
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => handleSearch(e.target.value)}
                    placeholder="Search products..."
                    className="w-full pl-10 pr-2 py-2 bg-transparent text-white placeholder-gray-400 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
                  />
                  <FaSearch className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400" />
                </div>
                {searchResults.length > 0 && (
                  <ul className="bg-[#3b2322] mt-2 rounded text-sm max-h-48 overflow-y-auto">
                    {searchResults.map((item, index) => (
                      <li
                        key={index}
                        onClick={() => {
                          addRecommendations({ product_id: item.id });
                          navigate(`/product/${item.id}`);
                        }}
                        className="px-4 py-2 hover:bg-[#4b2e2d] cursor-pointer"
                      >
                        {item.name}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>

          {/* Auth Buttons or User Profile */}
          {token ? (
            <>
              {/* User Profile */}
              <div className="relative" ref={profileRef}>
                <FaUser
                  className="cursor-pointer"
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                />
                {isProfileOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-[#2b1c1b] border border-gray-500 rounded-md shadow-lg z-50">
                    <div className="py-2" style={{ borderBottomWidth: "1px" }}>
                      <button
                        onClick={handleLogout}
                        className="w-full text-left px-4 py-2 hover:bg-[#4b2e2d]"
                      >
                        Logout
                      </button>
                    </div>
                    <div className="py-2">
                      <button
                        onClick={handleOrdersClick}
                        className="w-full text-left px-4 py-2 hover:bg-[#4b2e2d]"
                      >
                        Orders
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Cart */}
              <div className="relative">
                <FaShoppingBag
                  className="cursor-pointer"
                  onClick={handleCartToggle}
                />
                {totalQuantity > 0 && (
                  <span className="hidden sm:flex absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold w-5 h-5 rounded-full items-center justify-center">
                    {totalQuantity}
                  </span>
                )}
              </div>
            </>
          ) : (
            <div className="flex items-center space-x-4">
              <Link
                to="/login"
                className="px-4 py-2 text-sm font-medium text-white hover:text-gray-200"
              >
                Login
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* Nav Menu */}
      <nav className="hidden sm:block py-4 px-4 sm:px-8 bg-[#3b2322] border-b border-gray-700">
        <ul className="flex flex-row justify-center gap-12 text-xl font-medium">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <li key={item.name} className="relative group">
                <Link to={item.path}>
                  <span
                    className={`absolute left-[-16px] top-0 bottom-0 hidden group-hover:inline ${
                      isActive ? "inline" : ""
                    }`}
                  >
                    {"["}
                  </span>
                  <span
                    className={`absolute right-[-16px] top-0 bottom-0 hidden group-hover:inline ${
                      isActive ? "inline" : ""
                    }`}
                  >
                    {"]"}
                  </span>
                  {item.name}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {isCartOpen && <Cart onClose={() => setIsCartOpen(false)} />}
    </header>
  );
};

export default Header;
