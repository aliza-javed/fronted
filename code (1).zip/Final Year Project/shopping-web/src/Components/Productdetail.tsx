// src/components/ProductDetail.tsx

import React, { useEffect, useState } from "react";
import { useParams, } from "react-router-dom";
import { useCart } from "../contexts/CartContext";
import bannerImg from '../webassets/image-4-1.jpg';
import { useProduct } from "../contexts/ProductContext";
import { AddToCartRequest } from "../services/types/cart.types";
import { Product } from "../services/types/product.types";
import { getMediaUrl } from "../helpers";

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const productId = parseInt(id || "0");
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState<string>("");
  const [selectedLeather, setSelectedLeather] = useState<string>("");
  const { addToCart } = useCart();
  const { fetchProductById, currentProduct } = useProduct()

  // Fetch product from backend
  useEffect(() => {
    fetchProductById(productId)
    setLoading(false)
  }, [productId]);

  useEffect(() => {
    if (currentProduct) {
      setProduct(currentProduct)
    }
  }, [currentProduct])

  const handleAddToCart = () => {
    if (!product) return;

    const productToAdd: AddToCartRequest = {
      product_id: product.id,
      quantity: quantity,
    };

    addToCart(productToAdd);
  };

  if (loading) {
    return <div className="text-center text-xl mt-10">Loading...</div>;
  }

  if (!product) {
    return <div className="text-center text-xl mt-10">Product not found</div>;
  }

  return (
    <div className="bg-gray-50">
      {/* Top Banner */}
      <div className="relative w-full">
        <img
          src={bannerImg}
          alt="Product Banner"
          className="w-full h-64 md:h-96 object-cover object-center inset-0 bg-black opacity-70"
        />
        <div className="absolute inset-0 flex items-center justify-center z-50">
          <h1 className="text-white text-md md:text-3xl font-semibold px-6 py-3 rounded">
            Home / Products / {product.name}
          </h1>
        </div>
      </div>

      {/* Product Detail Section */}
      <div className="p-4 md:p-8 lg:p-16">
        <div className="flex flex-col md:flex-row gap-8 max-w-7xl mx-auto">
          {/* Product Image */}
          <div className="w-full md:w-[600px]">
            <img
              src={getMediaUrl(product.image)}
              alt={product.name}
              className="object-cover rounded-lg w-full h-[400px] md:h-[600px]"
            />
          </div>

          {/* Product Info */}
          <div className="w-full md:w-1/2">
            <h2 className="text-2xl font-semibold mb-2">{product.name}</h2>
            <p className="text-xl text-gray-700 mb-2">{product.price}</p>
            <p className="text-gray-600 text-xl mb-4">{product.description}</p>

            {product.category.name === "jacket" && (
              <>
                {/* Size Selection */}
                <div className="mb-4">
                  <h3 className="text-lg font-semibold">Size</h3>
                  <div className="flex flex-wrap gap-4">
                    {["Small", "Medium", "Large", "Extra Large"].map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`px-6 py-2 rounded-md border-2 ${selectedSize === size
                          ? "bg-black text-white"
                          : "bg-white text-black"
                          }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Leather Type */}
                <div className="mb-4">
                  <h3 className="text-lg font-semibold">Leather Type</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {[
                      "Full-Grain Leather",
                      "Genuine Leather",
                      "Top-Grain Leather",
                      "Exotic Leather",
                    ].map((leather) => (
                      <button
                        key={leather}
                        onClick={() => setSelectedLeather(leather)}
                        className={`px-6 py-2 rounded-md border-2 ${selectedLeather === leather
                          ? "bg-black text-white"
                          : "bg-white text-black"
                          }`}
                      >
                        {leather}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Quantity & Add to Cart */}
            <div className="mb-4 flex items-center gap-4">
              <div className="flex items-center border border-black rounded overflow-hidden">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-5 py-3 text-sm"
                >
                  -
                </button>
                <div className="px-5 py-3 text-sm bg-white border-l border-r border-black">
                  {quantity}
                </div>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-5 py-3 text-sm"
                >
                  +
                </button>
              </div>

              <button
                onClick={handleAddToCart}
                className="bg-black text-white px-12 py-4 rounded-lg hover:bg-gray-800 transition"
              >
                Add to Cart
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
