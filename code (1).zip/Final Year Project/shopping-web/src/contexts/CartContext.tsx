import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { Cart, AddToCartRequest, UpdateCartItemRequest } from '../services/types/cart.types';
import { CartService } from '../services/cart.service';
import { useAuth } from './AuthContext';

interface CartContextType {
  cart: Cart | null;
  loading: boolean;
  error: string | null;
  fetchCart: () => Promise<void>;
  addToCart: (data: AddToCartRequest) => Promise<void>;
  updateCartItem: (itemId: number, data: UpdateCartItemRequest) => Promise<void>;
  increaseQuantity: (itemId: number) => Promise<void>;
  decreaseQuantity: (itemId: number) => Promise<void>;
  removeItem: (itemId: number) => Promise<void>;
  clearError: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<Cart | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { token } = useAuth();
  const cartService = CartService.getInstance();

  const fetchCart = useCallback(async () => {
    if (!token) return;

    try {
      setLoading(true);
      setError(null);
      const cartData = await cartService.getCart();
      setCart(cartData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch cart');
    } finally {
      setLoading(false);
    }
  }, [token]);

  const addToCart = useCallback(async (data: AddToCartRequest) => {
    if (!token) return;

    try {
      setLoading(true);
      setError(null);
      const updatedCart = await cartService.addToCart(data);
      setCart(updatedCart);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add item to cart');
    } finally {
      setLoading(false);
    }
  }, [token]);

  const updateCartItem = useCallback(async (itemId: number, data: UpdateCartItemRequest) => {
    if (!token) return;

    try {
      setLoading(true);
      setError(null);
      const updatedCart = await cartService.updateCartItem(itemId, data);
      setCart(updatedCart);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update cart item');
    } finally {
      setLoading(false);
    }
  }, [token]);

  const increaseQuantity = useCallback(async (itemId: number) => {
    if (!token) return;

    try {
      setLoading(true);
      setError(null);
      await cartService.increaseCartItemQuantity(itemId);
      await fetchCart()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to increase quantity');
    } finally {
      setLoading(false);
    }
  }, [token]);

  const decreaseQuantity = useCallback(async (itemId: number) => {
    if (!token) return;

    try {
      setLoading(true);
      setError(null);
      await cartService.decreaseCartItemQuantity(itemId);
      await fetchCart()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to decrease quantity');
    } finally {
      setLoading(false);
    }
  }, [token]);

  const removeItem = useCallback(async (itemId: number) => {
    if (!token) return;

    try {
      setLoading(true);
      setError(null);
      await cartService.removeCartItem(itemId);
      await fetchCart()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to remove item');
    } finally {
      setLoading(false);
    }
  }, [token]);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // Fetch cart when token changes
  useEffect(() => {
    if (token) {
      fetchCart();
    } else {
      setCart(null);
    }
  }, [token, fetchCart]);

  const value = {
    cart,
    loading,
    error,
    fetchCart,
    addToCart,
    updateCartItem,
    increaseQuantity,
    decreaseQuantity,
    removeItem,
    clearError,
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};