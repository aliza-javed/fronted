// /src/contexts/productContext.tsx:


import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { Product, ProductFilters } from '../services/types/product.types';
import { ProductService } from '../services/product.service';

interface ProductContextType {
  products: Product[];
  currentProduct: Product | null;
  totalProducts: number;
  nextPage: string | null;
  previousPage: string | null;
  loading: boolean;
  error: string | null;
  fetchProducts: (filters?: ProductFilters) => Promise<Product[]>;
  fetchProductById: (id: number) => Promise<void>;
  fetchNewArrivals: (filters?: ProductFilters) => Promise<void>;
  clearError: () => void;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const ProductProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [currentProduct, setCurrentProduct] = useState<Product | null>(null);
  const [totalProducts, setTotalProducts] = useState(0);
  const [nextPage, setNextPage] = useState<string | null>(null);
  const [previousPage, setPreviousPage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const productService = ProductService.getInstance();

  useEffect(() => {
    fetchProducts()
  },[])

  const fetchProducts = useCallback(async (filters?: ProductFilters) => {
    try {
      setLoading(true);
      setError(null);
      const response = await productService.getProducts(filters);
      setProducts(response.results);
      setTotalProducts(response.count);
      setNextPage(response.next);
      setPreviousPage(response.previous);
      return response.results;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch products');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchProductById = useCallback(async (id: number) => {
    try {
      setLoading(true);
      setError(null);
      const product = await productService.getProductById(id);
      setCurrentProduct(product);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch product');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchNewArrivals = useCallback(async (filters?: ProductFilters) => {
    try {
      setLoading(true);
      setError(null);
      const response = await productService.getNewArrivals(filters);
      setProducts(response.results);
      setTotalProducts(response.count);
      setNextPage(response.next);
      setPreviousPage(response.previous);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch new arrivals');
    } finally {
      setLoading(false);
    }
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const value = {
    products,
    currentProduct,
    totalProducts,
    nextPage,
    previousPage,
    loading,
    error,
    fetchProducts,
    fetchProductById,
    fetchNewArrivals,
    clearError,
  };

  return (
    <ProductContext.Provider value={value}>
      {children}
    </ProductContext.Provider>
  );
};

export const useProduct = () => {
  const context = useContext(ProductContext);
  if (context === undefined) {
    throw new Error('useProduct must be used within a ProductProvider');
  }
  return context;
};