import React, { createContext, useContext, useState } from "react";
import { searchHistoryService } from "../services/search-history.service";
import {
  SearchHistoryItem,
  SearchHistoryRequest,
  DeleteSearchHistoryRequest,
} from "../services/types/search-history.types";
import { Product } from "../services/types/product.types";

export type Recommendation = {
  id: number;
  product: Product;
};

interface SearchHistoryContextType {
  searchHistory: SearchHistoryItem[];
  recommendations: Recommendation[];
  loading: boolean;
  error: string | null;
  addSearchHistory: (data: SearchHistoryRequest) => Promise<void>;
  deleteSearchHistory: (data: DeleteSearchHistoryRequest) => Promise<void>;
  clearSearchHistory: () => Promise<void>;
  fetchSearchHistory: () => Promise<void>;
  fetchRecommendations: () => Promise<void>;
  addRecommendations: (data: { product_id: number }) => Promise<void>;
}

const SearchHistoryContext = createContext<
  SearchHistoryContextType | undefined
>(undefined);

export const SearchHistoryProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [searchHistory, setSearchHistory] = useState<SearchHistoryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);

  const fetchSearchHistory = async () => {
    try {
      setLoading(true);
      const response = await searchHistoryService.getSearchHistory();
      setSearchHistory(response.results);
      setError(null);
    } catch (err) {
      setError("Failed to fetch search history");
      console.error("Error fetching search history:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecommendations = async () => {
    try {
      setLoading(true);
      const response = await searchHistoryService.getRecommendations();
      setRecommendations(response);
      setError(null);
    } catch (err) {
      setError("Failed to fetch recommendations");
      console.error("Error fetching recommendations:", err);
    } finally {
      setLoading(false);
    }
  };

  const addRecommendations = async (data: { product_id: number }) => {
    try {
      setLoading(true);
      await searchHistoryService.postRecommendations(data);
      setError(null);
    } catch (err) {
      setError("Failed to add recommendations");
      console.error("Error adding recommendations:", err);
    } finally {
      setLoading(false);
    }
  };

  // useEffect(() => {
  //   fetchSearchHistory();
  // }, []);

  const addSearchHistory = async (data: SearchHistoryRequest) => {
    try {
      await searchHistoryService.addSearchHistory(data);
      await fetchSearchHistory();
    } catch (err) {
      setError("Failed to add search history");
      console.error("Error adding search history:", err);
    }
  };

  const deleteSearchHistory = async (data: DeleteSearchHistoryRequest) => {
    try {
      await searchHistoryService.deleteSearchHistory(data);
      await fetchSearchHistory();
    } catch (err) {
      setError("Failed to delete search history");
      console.error("Error deleting search history:", err);
    }
  };

  const clearSearchHistory = async () => {
    try {
      await searchHistoryService.clearSearchHistory();
      setSearchHistory([]);
    } catch (err) {
      setError("Failed to clear search history");
      console.error("Error clearing search history:", err);
    }
  };

  return (
    <SearchHistoryContext.Provider
      value={{
        searchHistory,
        loading,
        error,
        addSearchHistory,
        deleteSearchHistory,
        clearSearchHistory,
        fetchSearchHistory,
        recommendations,
        fetchRecommendations,
        addRecommendations,
      }}
    >
      {children}
    </SearchHistoryContext.Provider>
  );
};

export const useSearchHistory = () => {
  const context = useContext(SearchHistoryContext);
  if (context === undefined) {
    throw new Error(
      "useSearchHistory must be used within a SearchHistoryProvider"
    );
  }
  return context;
};
