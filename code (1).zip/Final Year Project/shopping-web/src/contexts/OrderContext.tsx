import React, { createContext, useContext, useState, useCallback } from 'react';
import { OrderService } from '../services/order.service';
import { Order, CreateOrderRequest, UpdateOrderStatusRequest } from '../services/types/order.types';
import { useCart } from './CartContext';

interface OrderContextType {
  orders: Order[];
  currentOrder: Order | null;
  loading: boolean;
  error: string | null;
  fetchOrders: () => Promise<void>;
  fetchOrderById: (id: number) => Promise<void>;
  createOrder: (data: CreateOrderRequest) => Promise<void>;
  updateOrderStatus: (id: number, data: UpdateOrderStatusRequest) => Promise<void>;
  clearError: () => void;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const orderService = OrderService.getInstance();
  const {fetchCart} = useCart()

  const fetchOrders = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await orderService.getAllOrders();
      setOrders(data.results);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred while fetching orders');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchOrderById = useCallback(async (id: number) => {
    try {
      setLoading(true);
      setError(null);
      const data = await orderService.getOrderById(id);
      setCurrentOrder(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred while fetching order');
    } finally {
      setLoading(false);
    }
  }, []);

  const createOrder = useCallback(async (data: CreateOrderRequest) => {
    try {
      setLoading(true);
      setError(null);
      const newOrder = await orderService.createOrder(data);
      setOrders(prev => [...prev, newOrder]);
      fetchCart()
      setCurrentOrder(newOrder);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred while creating order');
    } finally {
      setLoading(false);
    }
  }, []);

  const updateOrderStatus = useCallback(async (id: number, data: UpdateOrderStatusRequest) => {
    try {
      setLoading(true);
      setError(null);
      const updatedOrder = await orderService.updateOrderStatus(id, data);
      setOrders(prev => prev.map(order => order.id === id ? updatedOrder : order));
      if (currentOrder?.id === id) {
        setCurrentOrder(updatedOrder);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred while updating order status');
    } finally {
      setLoading(false);
    }
  }, [currentOrder]);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const value = {
    orders,
    currentOrder,
    loading,
    error,
    fetchOrders,
    fetchOrderById,
    createOrder,
    updateOrderStatus,
    clearError
  };

  return <OrderContext.Provider value={value}>{children}</OrderContext.Provider>;
};

export const useOrder = () => {
  const context = useContext(OrderContext);
  if (context === undefined) {
    throw new Error('useOrder must be used within an OrderProvider');
  }
  return context;
}; 