import React, { createContext, useContext, useState } from 'react';
import { contactUsService } from '../services/contact-us.service';
import { ContactUsRequest, ContactUsResponse } from '../services/types/contact-us.types';

interface ContactUsContextType {
  loading: boolean;
  error: string | null;
  submitContactForm: (data: ContactUsRequest) => Promise<ContactUsResponse>;
  getContactStatus: (id: number) => Promise<ContactUsResponse>;
}

const ContactUsContext = createContext<ContactUsContextType | undefined>(undefined);

export const ContactUsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submitContactForm = async (data: ContactUsRequest): Promise<ContactUsResponse> => {
    try {
      setLoading(true);
      const response = await contactUsService.submitContactForm(data);
      setError(null);
      return response;
    } catch (err) {
      setError('Failed to submit contact form');
      console.error('Error submitting contact form:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const getContactStatus = async (id: number): Promise<ContactUsResponse> => {
    try {
      setLoading(true);
      const response = await contactUsService.getContactStatus(id);
      setError(null);
      return response;
    } catch (err) {
      setError('Failed to get contact status');
      console.error('Error getting contact status:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return (
    <ContactUsContext.Provider
      value={{
        loading,
        error,
        submitContactForm,
        getContactStatus,
      }}
    >
      {children}
    </ContactUsContext.Provider>
  );
};

export const useContactUs = () => {
  const context = useContext(ContactUsContext);
  if (context === undefined) {
    throw new Error('useContactUs must be used within a ContactUsProvider');
  }
  return context;
}; 