import React, { createContext, useContext, useState, useEffect } from 'react';
import { modifiersService } from '../services/modifiers.service';
import { Size, Leather, Color } from '../services/types/modifiers.types';

interface ModifiersContextType {
  sizes: Size[];
  leatherTypes: Leather[];
  colors: Color[];
  loading: boolean;
  error: string | null;
  fetchModifiers: () => Promise<void>;
}

const ModifiersContext = createContext<ModifiersContextType | undefined>(undefined);

export const ModifiersProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sizes, setSizes] = useState<Size[]>([]);
  const [leatherTypes, setLeatherTypes] = useState<Leather[]>([]);
  const [colors, setColors] = useState<Color[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchModifiers = async () => {
    try {
      setLoading(true);
      const response = await modifiersService.getModifiers();
      setSizes(response.sizes);
      setLeatherTypes(response.leather_types);
      setColors(response.colors);
      setError(null);
    } catch (err) {
      setError('Failed to fetch modifiers');
      console.error('Error fetching modifiers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchModifiers();
  }, []);

  return (
    <ModifiersContext.Provider
      value={{
        sizes,
        leatherTypes,
        colors,
        loading,
        error,
        fetchModifiers,
      }}
    >
      {children}
    </ModifiersContext.Provider>
  );
};

export const useModifiers = () => {
  const context = useContext(ModifiersContext);
  if (context === undefined) {
    throw new Error('useModifiers must be used within a ModifiersProvider');
  }
  return context;
}; 