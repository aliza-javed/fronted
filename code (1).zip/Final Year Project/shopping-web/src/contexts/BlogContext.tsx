import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { Blog } from '../services/types/blog.types';
import { BlogService } from '../services/blog.service';

interface BlogContextType {
  blogs: Blog[];
  currentBlog: Blog | null;
  loading: boolean;
  error: string | null;
  fetchAllBlogs: () => Promise<void>;
  fetchBlogById: (id: number) => Promise<void>;
  clearError: () => void;
}

const BlogContext = createContext<BlogContextType | undefined>(undefined);

export const BlogProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [currentBlog, setCurrentBlog] = useState<Blog | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const blogService = BlogService.getInstance();
  useEffect(() => {
    fetchAllBlogs()
  }, [])


  const fetchAllBlogs = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const blogList = await blogService.getAllBlogs();
      setBlogs(blogList);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch blogs');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchBlogById = useCallback(async (id: number) => {
    try {
      setLoading(true);
      setError(null);
      const blog = await blogService.getBlogById(id);
      setCurrentBlog(blog);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch blog');
    } finally {
      setLoading(false);
    }
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const value = {
    blogs,
    currentBlog,
    loading,
    error,
    fetchAllBlogs,
    fetchBlogById,
    clearError,
  };

  return (
    <BlogContext.Provider value={value}>
      {children}
    </BlogContext.Provider>
  );
};

export const useBlog = () => {
  const context = useContext(BlogContext);
  if (context === undefined) {
    throw new Error('useBlog must be used within a BlogProvider');
  }
  return context;
}; 