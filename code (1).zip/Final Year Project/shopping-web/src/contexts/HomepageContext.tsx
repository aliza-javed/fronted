import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { HomepageData } from '../services/types/homepage.types';
import { HomepageService } from '../services/homepage.service';

interface HomepageContextType {
  data: HomepageData | null;
  loading: boolean;
  error: string | null;
  fetchHomepageData: () => Promise<void>;
  clearError: () => void;
}

const HomepageContext = createContext<HomepageContextType | undefined>(undefined);

export const HomepageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<HomepageData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const homepageService = HomepageService.getInstance();

  const fetchHomepageData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const homepageData = await homepageService.getHomepageData();
      setData(homepageData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch homepage data');
    } finally {
      setLoading(false);
    }
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // Fetch homepage data on mount
  useEffect(() => {
    fetchHomepageData();
  }, [fetchHomepageData]);

  const value = {
    data,
    loading,
    error,
    fetchHomepageData,
    clearError,
  };

  return (
    <HomepageContext.Provider value={value}>
      {children}
    </HomepageContext.Provider>
  );
};

export const useHomepage = () => {
  const context = useContext(HomepageContext);
  if (context === undefined) {
    throw new Error('useHomepage must be used within a HomepageProvider');
  }
  return context;
}; 