// src/helpers.ts

const MEDIA_URL = import.meta.env.VITE_MEDIA_URL || 'http://localhost:8000';

export function getMediaUrl(url: string) {
    if (url?.startsWith("http") || !url) {
        return url
    }
    
    return MEDIA_URL + url
}
