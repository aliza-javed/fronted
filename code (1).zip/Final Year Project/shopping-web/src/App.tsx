import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import { CartProvider } from "./contexts/CartContext";
import { OrderProvider } from "./contexts/OrderContext";
import { ProductProvider } from "./contexts/ProductContext";
import { CategoryProvider } from "./contexts/CategoryContext";
import ErrorBoundary from "./ErrorBoundry";
import Header from "./Components/header";
import Footer from "./Components/footer";
import Home from "./Pages/Hheader";
import Shop from "./Pages/Sheader";
import NewArrival from "./Pages/Arrheader";
import Blog from "./Pages/Bheader";
import ContactUs from "./Pages/Cheader";
import AboutUs from "./Pages/Aheader";
import ProductDetails from "./Components/Productdetail";
import Login from "./Components/Login";
import { ModifiersProvider } from "./contexts/ModifiersContext";
import { BlogProvider } from "./contexts/BlogContext";
import { ContactUsProvider } from "./contexts/ContactUsContext";
import { HomepageProvider } from "./contexts/HomepageContext";
// import Signup from "./Mainpages/Signup";
import Checkout from "./Mainpages/Checkout";
import Profile from "./Mainpages/Profile";
import { SearchHistoryProvider } from "./contexts/SearchHistoryContext";

function App() {
  return (
    <ErrorBoundary>
      <Router>
        <AuthProvider>
          <CartProvider>
            <OrderProvider>
              <ProductProvider>
                <CategoryProvider>
                  <BlogProvider>
                    <ContactUsProvider>
                      <HomepageProvider>
                        <SearchHistoryProvider>
                          <ModifiersProvider>
                            <div className="flex flex-col min-h-screen">
                              <Header />
                              <main className="flex-grow">
                                <Routes>
                                  <Route path="/" element={<Home />} />
                                  <Route path="/shop" element={<Shop />} />
                                  <Route
                                    path="/new-arrival"
                                    element={<NewArrival />}
                                  />
                                  <Route path="/blog" element={<Blog />} />
                                  <Route
                                    path="/contact-us"
                                    element={<ContactUs />}
                                  />
                                  <Route
                                    path="/about-us"
                                    element={<AboutUs />}
                                  />
                                  <Route
                                    path="/product/:id"
                                    element={<ProductDetails />}
                                  />
                                  <Route path="/login" element={<Login />} />
                                  {/* <Route path="/signup" element={<Signup />} /> */}
                                  <Route
                                    path="/checkout"
                                    element={<Checkout />}
                                  />
                                  <Route
                                    path="/profile"
                                    element={<Profile />}
                                  />
                                </Routes>
                              </main>
                              <Footer />
                            </div>
                          </ModifiersProvider>
                        </SearchHistoryProvider>
                      </HomepageProvider>
                    </ContactUsProvider>
                  </BlogProvider>
                </CategoryProvider>
              </ProductProvider>
            </OrderProvider>
          </CartProvider>
        </AuthProvider>
      </Router>
    </ErrorBoundary>
  );
}

export default App;
