// src/config/api.js

import { useEffect, useState } from 'react';
import { fetchProducts } from './config/api'; // Import the API function

function App() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadProducts = async () => {
      try {
        const data = await fetchProducts();
        setProducts(data);
      } catch (error) {
        console.error('API fetch error:', error);
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, []);

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Product List</h1>
      {loading ? (
        <p>Loading...</p>
      ) : products.length === 0 ? (
        <p>No products found.</p>
      ) : (
        <ul className="space-y-2">
          {products.map((product, index) => (
            <li
              key={index}
              className="p-4 border border-gray-300 rounded shadow-sm bg-white"
            >
              <strong>{product.name}</strong><br />
              Price: ${product.price}<br />
              Description: {product.description}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;