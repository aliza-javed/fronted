export interface LoginResponse {
  token: string;
  user: {
    id: number;
    email: string;
  };
}

export interface SignupResponse {
  id: number;
  email: string;
}

export interface AuthCredentials {
  email: string;
  password: string;
}
