import axios from "axios";

const BACKEND_URL = "https://6a5f-110-39-21-146.ngrok-free.app";

declare global {
  interface Window {
    "ngrok-skip-browser-warning": boolean;
  }
}

window["ngrok-skip-browser-warning"] = true;

const api = axios.create({
  baseURL: BACKEND_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

export default api;
