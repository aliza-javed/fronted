// src/config/api.tsx

import axios from 'axios';

// Define the API base URL
export const BACKEND_URL = "http://localhost:8000"
export const API_BASE = BACKEND_URL + '/api';

// Configure Axios instance with the base URL
const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Fetch products from the API
export const fetchProducts = async () => {
  try {
    const response = await api.get('/products/');
    return response.data;  // Return the list of products
  } catch (error) {
    throw new Error('Error fetching products');
  }
};

// User login function
export const loginUser = async (username: string, password: string) => {
  try {
    const response = await api.post('/login/', {
      username,
      password,
    });
    return response.data;  // Return user login data, e.g., tokens
  } catch (error) {
    throw new Error('Login failed');
  }
};

// User signup function
export const signupUser = async (username: string, password: string, email: string) => {
  try {
    const response = await api.post('/signin/', {
      username,
      password,
      email,
    });
    return response.data;  // Return signup response
  } catch (error) {
    throw new Error('Signup failed');
  }
};